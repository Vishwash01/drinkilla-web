// Profile dropdown toggle
const profileBtn = document.getElementById('profileBtn');
const profileDropdown = document.getElementById('profileDropdown');

profileBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    profileDropdown.classList.toggle('active');
});

// Close dropdown when clicking outside
document.addEventListener('click', function() {
    profileDropdown.classList.remove('active');
});

// Mobile menu toggle
document.querySelector('.hamburger').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
});

// Add to cart functionality
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        const cartCount = document.querySelector('.cart-count');
        let count = parseInt(cartCount.textContent);
        cartCount.textContent = count + 1;
        
        this.innerHTML = '<i class="fas fa-check"></i>';
        setTimeout(() => {
            this.innerHTML = '<i class="fas fa-plus"></i>';
        }, 1000);
    });
});

// 3D Bottle Animation
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
    75, window.innerWidth / window.innerHeight, 0.1, 1000
);

const renderer = new THREE.WebGLRenderer({ 
    alpha: true,
    antialias: true
});
renderer.setSize(window.innerWidth, window.innerHeight);
document.getElementById('beer-3d').appendChild(renderer.domElement);

// Lighting
const light = new THREE.DirectionalLight(0xffffff, 1);
light.position.set(1, 1, 2).normalize();
scene.add(light);

const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
scene.add(ambientLight);

let beer;
let lastScrollY = window.scrollY;
let rotationY = 0;

const loader = new THREE.GLTFLoader();
// For demo purposes, we'll create a simple bottle geometry
// In a real app, you would load your beer.glb model:
 loader.load('models/beer.glb', function(gltf) {
     beer = gltf.scene;
     beer.scale.set(2, 1.5, 2);
     scene.add(beer);
     camera.position.z = 3;
});

// Create a placeholder bottle geometry if the model is not loaded
// Remove this block if you are loading a real .glb model
const bottleGeometry = new THREE.CylinderGeometry(0.3, 0.2, 1, 32);
const bottleMaterial = new THREE.MeshPhongMaterial({ 
    color: 0x996633,
    transparent: true,
    opacity: 0.8,
    shininess: 100
});
beer = new THREE.Mesh(bottleGeometry, bottleMaterial);
scene.add(beer);
camera.position.z = 3;


function animate() {
    requestAnimationFrame(animate);
    
    const currentScrollY = window.scrollY || window.pageYOffset;
    const scrollDelta = currentScrollY - lastScrollY;

    if (beer) {
        rotationY += scrollDelta * 0.005;
        beer.rotation.y = rotationY;
    }

    lastScrollY = currentScrollY;

    renderer.render(scene, camera);
}

animate();

window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});