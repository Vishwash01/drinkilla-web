// Function to display messages (now targeted to a specific JS message area)
function displayJsMessage(message, type) {
    const messageArea = document.getElementById('js-message-area');
    messageArea.innerHTML = `<p class="form-message ${type}">${message}</p>`;
    // Optional: Auto-hide message after a few seconds
    // setTimeout(() => {
    //     messageArea.innerHTML = '';
    // }, 5000); 
}

document.getElementById('signup-form').addEventListener('submit', function(event) {
    // Clear previous JS messages
    document.getElementById('js-message-area').innerHTML = '';

    const fullName = document.getElementById('fullName').value.trim();
    const mobileNumber = document.getElementById('mobileNumber').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const termsAccepted = document.getElementById('termsCheckbox').checked;

    let isValid = true; // Flag to track overall validation status
    let errorMessage = '';

    // --- Client-Side Validation ---
    if (!fullName || !mobileNumber || !email || !password) {
        errorMessage += 'Please fill in all fields.<br>';
        isValid = false;
    }

    // Basic mobile number validation
    if (mobileNumber.length !== 10 || !/^\d{10}$/.test(mobileNumber)) {
        errorMessage += 'Please enter a valid 10-digit mobile number.<br>';
        isValid = false;
    }

    if (!termsAccepted) {
        errorMessage += 'You must agree to the terms & privacy policy.<br>';
        isValid = false;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        errorMessage += 'Please enter a valid email address.<br>';
        isValid = false;
    }

    // Basic password strength check
    if (password.length < 6) {
        errorMessage += 'Password must be at least 6 characters long.<br>';
        isValid = false;
    }
    // --- End Client-Side Validation ---

    if (!isValid) {
        event.preventDefault(); // Stop the form from submitting
        displayJsMessage(errorMessage, 'error');
    } 
    // If isValid is true, the form will submit normally to signup_process.php
});

