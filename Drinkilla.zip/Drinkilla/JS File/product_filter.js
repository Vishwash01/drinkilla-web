document.addEventListener('DOMContentLoaded', function() {
    const categoryFilter = document.getElementById('category-filter');
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    const clearFiltersBtn = document.getElementById('clear-filters-btn');
    const productGridContainer = document.getElementById('product-grid-container');
    const noProductsMessage = document.getElementById('no-products-message');

    // Function to fetch and display products
    async function fetchAndDisplayProducts() {
        const categoryId = categoryFilter.value;
        const searchQuery = searchInput.value.trim();

        // Prepare form data to send to PHP
        const formData = new FormData();
        formData.append('category_id', categoryId);
        formData.append('search_query', searchQuery);

        try {
            const response = await fetch('includes/fetch_products.php', {
                method: 'POST',
                body: formData // Send data as form data
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json(); // Parse JSON response

            if (data.success) {
                renderProducts(data.products); // Update the product display
            } else {
                alert('Error fetching products: ' + data.message);
                console.error('Server response error:', data.message);
                renderProducts([]); // Clear products on error
            }
        } catch (error) {
            console.error('Fetch error:', error);
            alert('An error occurred while fetching products. Please try again.');
            renderProducts([]); // Clear products on error
        }
    }

    // Function to render products in the HTML
    function renderProducts(products) {
        productGridContainer.innerHTML = ''; // Clear existing products
        if (products.length > 0) {
            noProductsMessage.style.display = 'none'; // Hide "No products found" message
            products.forEach(product => {
                const productCard = document.createElement('div');
                productCard.classList.add('product-card');
                productCard.innerHTML = `
                    <img src="${product.image_url ? product.image_url : 'placeholder.jpg'}" alt="${product.product_name}">
                    <h3>${product.product_name}</h3>
                    <p class="product-description">${product.description ? product.description : ''}</p>
                    <p class="product-category">Category: ${product.category_name ? product.category_name : 'N/A'}</p>
                    <p class="product-price">₹${parseFloat(product.price_per_unit).toFixed(2)} / ${product.unit}</p>
                    <button class="add-to-cart-btn" data-product-id="${product.id}">Add to Cart</button>
                `;
                productGridContainer.appendChild(productCard);
            });
        } else {
            noProductsMessage.style.display = 'block'; // Show "No products found" message
        }
    }

    // Event Listeners
    categoryFilter.addEventListener('change', fetchAndDisplayProducts); // Filter when category changes
    searchBtn.addEventListener('click', fetchAndDisplayProducts); // Search when button clicked
    searchInput.addEventListener('keypress', function(event) { // Search on Enter key press in search input
        if (event.key === 'Enter') {
            event.preventDefault(); // Prevent form submission
            fetchAndDisplayProducts();
        }
    });

    clearFiltersBtn.addEventListener('click', () => {
        categoryFilter.value = '0'; // Reset category to 'All'
        searchInput.value = ''; // Clear search input
        fetchAndDisplayProducts(); // Fetch all products again
    });

    // Optional: Call fetchAndDisplayProducts on initial load if you don't want PHP to render initial products
    // (If you rely on the PHP initial load, you don't need this here, but useful if you disable PHP initial load)
    // fetchAndDisplayProducts(); 
});