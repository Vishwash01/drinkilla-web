// Sidebar navigation active state
document.querySelectorAll('.sidebar ul li').forEach(item => {
    item.addEventListener('click', function() {
        document.querySelectorAll('.sidebar ul li').forEach(li => li.classList.remove('active'));
        this.classList.add('active');
    });
});

// Wishlist toggle functionality
document.querySelectorAll('.wishlist-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const icon = this.querySelector('i');
        // Toggle between 'far' (regular) and 'fas' (solid) heart icons
        if (icon.classList.contains('far')) {
            icon.classList.remove('far');
            icon.classList.add('fas');
            this.style.color = 'var(--accent)'; // Apply accent color when liked
        } else {
            icon.classList.remove('fas');
            icon.classList.add('far');
            this.style.color = 'var(--gray)'; // Revert to default color
        }
    });
});



// Profile dropdown toggle for desktop
const profileButton = document.getElementById('profileButton');
const profileDropdown = document.getElementById('profileDropdown');

if (profileButton && profileDropdown) {
    profileButton.addEventListener('click', function(e) {
        e.stopPropagation(); // Prevent click from bubbling up and closing immediately
        profileDropdown.classList.toggle('show');
    });
}

// Mobile profile button (currently just an alert)
const mobileProfileButton = document.getElementById('mobileProfileButton');
if (mobileProfileButton) {
    mobileProfileButton.addEventListener('click', function(e) {
        e.stopPropagation();
        alert("This button would open a mobile-friendly profile menu!");
        // You would typically open a modal or navigate to a profile page here.
    });
}

// Close profile dropdown when clicking anywhere outside it
document.addEventListener('click', function(e) {
    if (profileDropdown && profileDropdown.classList.contains('show') && !profileDropdown.contains(e.target) && e.target !== profileButton) {
        profileDropdown.classList.remove('show');
    }
});

// Prevent dropdown from closing when clicking inside it
if (profileDropdown) {
    profileDropdown.addEventListener('click', function(e) {
        e.stopPropagation(); // Keep dropdown open when clicking within it
    });
}