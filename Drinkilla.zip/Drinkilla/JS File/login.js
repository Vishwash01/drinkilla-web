const continueBtn = document.getElementById('continue-btn');
const phoneInput = document.getElementById('phone');
const otpSection = document.getElementById('otp-section');
const phoneSection = document.querySelector('.phone-section');
const resendBtn = document.getElementById('resend-btn');
const timer = document.getElementById('timer');
const verifyBtn = document.getElementById('verify-btn'); // Get the verify button
const otpInput = document.getElementById('otp'); // Get the OTP input field

let countdown; // Variable to hold the timer interval

// Event listener for the "Continue" button (after entering phone number)
continueBtn.addEventListener('click', () => {
    const phone = phoneInput.value.trim();
    if (phone.length === 10 && /^\d{10}$/.test(phone)) { // Added regex for digit-only check
        // In a real scenario, you would send this phone number to a server
        // to request an OTP be sent, and only then show the OTP section.
        // For now, we're assuming the OTP sending is implicitly handled or mocked.

        phoneSection.style.display = 'none';
        otpSection.style.display = 'flex'; // Use flex to match your CSS display
        startTimer(); // Start the resend timer
    } else {
        alert('Please enter a valid 10-digit mobile number.');
    }
});

// Event listener for the "Verify OTP" button
verifyBtn.addEventListener('click', () => {
    const otp = otpInput.value.trim();
    const phone = phoneInput.value.trim(); // Get the phone number again for the AJAX call

    if (otp.length === 6) {
        // Send OTP and phone number to server for verification via AJAX
        fetch('includes/verify_otp.php', { // Ensure this path is correct relative to login.php
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded', // Sending data as URL-encoded form data
            },
            // The body contains the data sent to the PHP script
            body: `mobileNumber=${encodeURIComponent(phone)}&otp=${encodeURIComponent(otp)}`
        })
        .then(response => {
            // Check if the network request was successful (HTTP status 200-299)
            if (!response.ok) {
                // If not, throw an error to be caught by .catch()
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json(); // Parse the JSON response from the PHP script
        })
        .then(data => {
            // 'data' is the JSON object returned by includes/verify_otp.php
            if (data.success) {
                // If the PHP script indicates success
                alert(data.message); // Display the success message (e.g., "Login successful!")
                window.location.href = data.redirect; // Redirect to productdash.php
            } else {
                // If the PHP script indicates failure (e.g., invalid OTP)
                alert(data.message); // Display the error message
            }
        })
        .catch(error => {
            // Catch any network errors or errors thrown in the .then() block
            console.error('Error during OTP verification fetch:', error);
            alert('An unexpected error occurred. Please try again.');
        });

    } else {
        alert('Enter a valid 6-digit OTP.');
    }
});

// Function to manage the OTP resend timer
function startTimer() {
    let time = 30; // Initial countdown time
    resendBtn.disabled = true; // Disable the resend button during countdown
    resendBtn.innerHTML = `Resend in <span id="timer">${time}</span>s`; // Display initial time

    clearInterval(countdown); // Clear any existing timer to prevent multiple timers running
    countdown = setInterval(() => {
        time--;
        timer.textContent = time; // Update the displayed time

        if (time <= 0) {
            clearInterval(countdown); // Stop the timer when it reaches zero
            resendBtn.disabled = false; // Enable the resend button
            resendBtn.textContent = "Resend OTP"; // Change button text
        }
    }, 1000); // Update every 1 second
}

// Event listener for the "Resend OTP" button
resendBtn.addEventListener('click', () => {
    // In a real application, you'd send an AJAX request here to request a new OTP.
    alert('OTP resent! (This is a placeholder. Real resend logic needed.)');
    startTimer(); // Restart the timer
});

// Optional: If you have a general message display area in login.php that JS needs to manage
// function displayJsMessage(message, type) {
//     const messageArea = document.getElementById('js-message-area'); // Assuming an element with this ID
//     if (messageArea) {
//         messageArea.innerHTML = `<p class="form-message ${type}">${message}</p>`;
//         // Optional: Auto-hide message after a few seconds
//         // setTimeout(() => {
//         //     messageArea.innerHTML = '';
//         // }, 5000); 
//     }
// }