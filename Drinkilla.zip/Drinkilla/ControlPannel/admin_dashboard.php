<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Path to db_connection.php: from ControlPannel/ go up one level (to Drinkilla/), then into 'includes/'
require_once 'db_connection.php';

// --- ADMIN AUTHENTICATION CHECK ---
// Check if the admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // If not logged in as admin, redirect to the admin login page
    // Using absolute path for logout to redirect to login
    header('Location: /Drinkilla/ControlPannel/index.php?message=' . urlencode('Access denied. Please log in as an administrator.') . '&type=error');
    exit();
}
// --- END ADMIN AUTHENTICATION CHECK ---

// Fetch some quick stats for the dashboard (optional but good to have)
$total_products = 0;
$total_orders = 0;
$pending_orders = 0;

// Get total products count
$stmt_products = $conn->prepare("SELECT COUNT(*) AS total_products FROM products");
if ($stmt_products) {
    $stmt_products->execute();
    $result_products = $stmt_products->get_result();
    if ($row = $result_products->fetch_assoc()) {
        $total_products = $row['total_products'];
    }
    $stmt_products->close();
} else {
    error_log("Error preparing products count: " . $conn->error);
}


// Get total orders count
$stmt_orders = $conn->prepare("SELECT COUNT(*) AS total_orders FROM orders");
if ($stmt_orders) {
    $stmt_orders->execute();
    $result_orders = $stmt_orders->get_result();
    if ($row = $result_orders->fetch_assoc()) {
        $total_orders = $row['total_orders'];
    }
    $stmt_orders->close();
} else {
    error_log("Error preparing total orders count: " . $conn->error);
}


// Get pending orders count
$stmt_pending = $conn->prepare("SELECT COUNT(*) AS pending_orders FROM orders WHERE status = 'Pending'");
if ($stmt_pending) {
    $stmt_pending->execute();
    $result_pending = $stmt_pending->get_result();
    if ($row = $result_pending->fetch_assoc()) {
        $pending_orders = $row['pending_orders'];
    }
    $stmt_pending->close();
} else {
    error_log("Error preparing pending orders count: " . $conn->error);
}

$conn->close();

$admin_full_name = $_SESSION['admin_full_name'] ?? $_SESSION['admin_username'] ?? 'Admin'; // Fallback if full_name not set
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DrinkDrop - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="admincss/admin_dashboard_styles.css"/>
</head>
<body>
    <div class="container">
        <header class="header-bar">
            <h1><i class="fas fa-cogs"></i> Admin Dashboard <span>| DrinkDrop</span></h1>
            <a href="/Drinkilla/logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </header>

        <?php
        // Display messages from GET parameters (e.g., from admin_login.php)
        if (isset($_GET['message'])) {
            $display_message = htmlspecialchars($_GET['message']);
            $display_type = isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'info';
            echo "<div class='message-container {$display_type} show'>";
            echo "  <i class='" . ($display_type == 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle') . "'></i>";
            echo "  <span>{$display_message}</span>";
            echo "</div>";
            // JavaScript to hide the message after a few seconds
            echo "<script>";
            echo "  setTimeout(() => {";
            echo "    const msgContainer = document.querySelector('.message-container');";
            echo "    if (msgContainer) {";
            echo "      msgContainer.classList.remove('show');"; // Trigger fade-out
            echo "      setTimeout(() => msgContainer.remove(), 500);"; // Remove from DOM after transition
            echo "    }";
            echo "  }, 3000);"; // Message disappears after 3 seconds
            echo "</script>";
        }
        ?>

        <div class="dashboard-grid">
            <div class="dashboard-card card-products">
                <i class="fas fa-box-open icon"></i>
                <h3>Product Management</h3>
                <p>Add, edit, and remove products from your inventory.</p>
                <div class="count"><?php echo $total_products; ?></div>
                <p>Total Products</p>
                <a href="products.php" class="btn">Go to Products</a>
            </div>

            <div class="dashboard-card card-orders">
                <i class="fas fa-clipboard-list icon"></i>
                <h3>Order Management</h3>
                <p>View and manage all customer orders and their statuses.</p>
                <div class="count"><?php echo $total_orders; ?></div>
                <p>Total Orders</p>
                <a href="admin_orders.php" class="btn">Go to Order Manager</a>
            </div>

            <div class="dashboard-card card-pending">
                <i class="fas fa-hourglass-half icon"></i>
                <h3>Pending Orders</h3>
                <p>Orders that are awaiting processing or action.</p>
                <div class="count"><?php echo $pending_orders; ?></div>
                <p>Orders Pending</p>
                <a href="admin_orders.php?status=Pending" class="btn">View Pending</a>
            </div>
        </div>
    </div>
</body>
</html>