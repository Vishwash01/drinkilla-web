<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Adjust this path if db_connection.php is in a different location relative to admin_orders.php
require_once 'db_connection.php'; 

// --- ADMIN AUTHENTICATION CHECK ---
// Check if the admin is logged in using the session variable set in admin_login.php
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // If not logged in as admin, redirect to the admin login page
    header('Location: index.php?message=' . urlencode('Access denied. Please log in as an administrator.') . '&type=error');
    exit();
}
// --- END ADMIN AUTHENTICATION CHECK ---

$orders = []; // Array to store all orders

// --- Handle Order Status Update (if form is submitted) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update_status') {
    $order_id_to_update = intval($_POST['order_id']);
    $new_status = htmlspecialchars(trim($_POST['new_status']));

    // Validate new_status against allowed values to prevent arbitrary data
    $allowed_statuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
    if (!in_array($new_status, $allowed_statuses)) {
        // Invalid status provided, set an error message
        header('Location: admin_orders.php?message=' . urlencode('Invalid status provided.') . '&type=error');
        exit();
    }

    $stmt_update_status = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
    if ($stmt_update_status) {
        $stmt_update_status->bind_param("si", $new_status, $order_id_to_update);
        if ($stmt_update_status->execute()) {
            header('Location: admin_orders.php?message=' . urlencode('Order status updated successfully!') . '&type=success');
            exit();
        } else {
            header('Location: admin_orders.php?message=' . urlencode('Failed to update order status: ' . $stmt_update_status->error) . '&type=error');
            exit();
        }
        $stmt_update_status->close();
    } else {
        header('Location: admin_orders.php?message=' . urlencode('Database error preparing status update.') . '&type=error');
        exit();
    }
}
// --- End Handle Order Status Update ---


// --- Fetch All Orders ---
// We join with the 'users' table (assuming your consumer user table is 'users')
// to get the user's full_name and email if they are a registered user.
// If user_id is NULL (guest checkout), we'll use customer_name/email from the orders table.
// Ensure 'id' is the primary key in your 'users' table.
$sql_orders = "SELECT 
                    o.order_id, 
                    o.user_id, 
                    o.total_amount, 
                    o.order_date, 
                    o.status,
                    o.customer_name,     -- From orders table for guests
                    o.customer_email,    -- From orders table for guests
                    o.customer_phone,
                    o.shipping_address,
                    o.shipping_city,
                    o.shipping_state,
                    o.shipping_zip,
                    u.full_name AS registered_user_name, -- From users table for logged-in users
                    u.email AS registered_user_email     -- From users table for logged-in users
                FROM 
                    orders o
                LEFT JOIN 
                    customer u ON o.user_id = u.id
                ORDER BY 
                    o.order_date DESC";

$stmt_orders = $conn->prepare($sql_orders);

if ($stmt_orders) {
    $stmt_orders->execute();
    $result_orders = $stmt_orders->get_result();

    while ($order = $result_orders->fetch_assoc()) {
        $order_id = $order['order_id'];
        $order['items'] = []; // Initialize an array to store items for this order

        // Fetch items for the current order
        // Ensure 'product_id' is the primary key in your 'products' table.
        $sql_items = "SELECT oi.quantity, oi.price_at_purchase, p.name AS product_name 
                      FROM order_items oi
                      JOIN products p ON oi.product_id = p.product_id
                      WHERE oi.order_id = ?";
        $stmt_items = $conn->prepare($sql_items);

        if ($stmt_items) {
            $stmt_items->bind_param("i", $order_id);
            $stmt_items->execute();
            $result_items = $stmt_items->get_result();

            while ($item = $result_items->fetch_assoc()) {
                $order['items'][] = $item;
            }
            $stmt_items->close();
        } else {
            error_log("Failed to prepare statement for order items (Admin): " . $conn->error);
        }
        $orders[] = $order; // Add the order (with its items) to the orders array
    }
    $stmt_orders->close();
} else {
    error_log("Failed to prepare statement for all orders (Admin): " . $conn->error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DrinkDrop - Admin Order Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="admincss/admin_orders_styles.css"/>
    
</head>
<body>
    <div class="container">
        <header class="page-header">
            <h1><i class="fas fa-tools"></i> Admin Order Management</h1>
            <p>View and manage all customer orders</p>
        </header>

        <?php
        // Display messages from GET parameters after redirection
        if (isset($_GET['message'])) {
            $display_message = htmlspecialchars($_GET['message']);
            $display_type = isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'info';
            echo "<div class='message-container {$display_type} show'>";
            echo "  <i class='" . ($display_type == 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle') . "'></i>";
            echo "  <span>{$display_message}</span>";
            echo "</div>";
            // JavaScript to hide the message after a few seconds
            echo "<script>";
            echo "  setTimeout(() => {";
            echo "    const msgContainer = document.querySelector('.message-container');";
            echo "    if (msgContainer) {";
            echo "      msgContainer.classList.remove('show');";
            echo "      setTimeout(() => msgContainer.remove(), 500);"; // Wait for CSS transition
            echo "    }";
            echo "  }, 3000);";
            echo "</script>";
        }
        ?>

        <div class="order-table-container">
            <?php if (!empty($orders)): ?>
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Items</th>
                            <th>Shipping Info</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td class="order-id">#<?php echo htmlspecialchars($order['order_id']); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($order['registered_user_name'] ?? $order['customer_name']); ?></strong><br>
                                    <span class="customer-info"><?php echo htmlspecialchars($order['registered_user_email'] ?? $order['customer_email']); ?></span><br>
                                    <span class="customer-info"><?php echo htmlspecialchars($order['customer_phone']); ?></span>
                                </td>
                                <td class="total-amount">₹<?php echo number_format($order['total_amount'], 2); ?></td>
                                <td class="order-date"><?php echo date('Y-m-d H:i', strtotime($order['order_date'])); ?></td>
                                <td>
                                    <ul class="order-items-list">
                                        <?php if (!empty($order['items'])): ?>
                                            <?php foreach ($order['items'] as $item): ?>
                                                <li>
                                                    <span><?php echo htmlspecialchars($item['product_name']); ?></span>
                                                    <span>x<?php echo htmlspecialchars($item['quantity']); ?> (₹<?php echo number_format($item['price_at_purchase'], 2); ?>)</span>
                                                </li>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <li>No items found.</li>
                                        <?php endif; ?>
                                    </ul>
                                </td>
                                <td>
                                    <span class="customer-info"><?php echo htmlspecialchars($order['shipping_address']); ?></span><br>
                                    <span class="customer-info"><?php echo htmlspecialchars($order['shipping_city'] . ', ' . $order['shipping_state'] . ' - ' . $order['shipping_zip']); ?></span>
                                </td>
                                <td>
                                    <span class="status-badge status-<?php echo htmlspecialchars($order['status']); ?>">
                                        <?php echo htmlspecialchars($order['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <form action="admin_orders.php" method="POST" class="status-form">
                                        <input type="hidden" name="action" value="update_status">
                                        <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($order['order_id']); ?>">
                                        <select name="new_status" onchange="this.form.submit()">
                                            <?php
                                            $statuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
                                            foreach ($statuses as $status_option) {
                                                $selected = ($order['status'] == $status_option) ? 'selected' : '';
                                                echo "<option value='{$status_option}' {$selected}>{$status_option}</option>";
                                            }
                                            ?>
                                        </select>
                                        </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-orders-message">
                    <p>No orders found in the system.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>