<?php
session_start(); // Make sure session_start() is the very first thing

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Path to db_connection.php: from ControlPannel/ go up one level (to Drinkilla/), then into 'includes/'
require_once 'db_connection.php';

// --- ADMIN AUTHENTICATION CHECK (from admin_auth.php equivalent) ---
// This block ensures only logged-in admins can access this page.
// The 'admin_auth.php' file is effectively merged here for simplicity and to avoid circular includes.
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Redirect to the dedicated admin login page with an error message
    header("Location: /Drinkilla/ControlPannel/index.php?message=" . urlencode("Access denied. Please log in as an administrator.") . "&type=error");
    exit(); // Stop script execution
}
// --- END ADMIN AUTHENTICATION CHECK ---


// Fetch all products from the database
$sql = "SELECT product_id, name, category, price, alcohol_percentage, volume, image_url, is_bestseller, is_new
        FROM products
        ORDER BY name ASC"; // Order them alphabetically by name

$result = $conn->query($sql);

// Initialize an array to hold products
$products = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
} else if (!$result) {
    // Log database error if query fails
    error_log("Database query failed in products.php: " . $conn->error);
    // Optionally, display a user-friendly error message
    $message = "Error fetching products from the database.";
    $type = "error";
}

$conn->close(); // Close the database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drinkila - Admin Product Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="admincss/admin_products_styles.css">
</head>
<body>
    <div class="container">
        <header class="page-header">
            <h1><i class="fas fa-wine-bottle"></i> Manage Products</h1>
            <p>Add, edit, and remove products from your Drinkila store.</p>
        </header>

        <?php
        // Display messages from GET parameters (e.g., from add/edit/delete product pages)
        // Or internal errors like database query failure
        if (isset($_GET['message'])) {
            $display_message = htmlspecialchars($_GET['message']);
            $display_type = isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'info';
            echo "<div class='message-container {$display_type} show'>";
            echo "  <i class='" . ($display_type == 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle') . "'></i>";
            echo "  <span>{$display_message}</span>";
            echo "</div>";
            // JavaScript to hide the message after a few seconds
            echo "<script>";
            echo "  setTimeout(() => {";
            echo "    const msgContainer = document.querySelector('.message-container');";
            echo "    if (msgContainer) {";
            echo "      msgContainer.classList.remove('show');"; // Trigger fade-out
            echo "      setTimeout(() => msgContainer.remove(), 500);"; // Remove from DOM after transition
            echo "    }";
            echo "  }, 3000);"; // Message disappears after 3 seconds
            echo "</script>";
        } else if (isset($message)) { // Display internal error messages
             echo "<div class='message-container {$type} show'>";
             echo "  <i class='fas fa-exclamation-circle'></i>";
             echo "  <span>{$message}</span>";
             echo "</div>";
             echo "<script>"; // Also make internal errors vanish
             echo "  setTimeout(() => {";
             echo "    const msgContainer = document.querySelector('.message-container');";
             echo "    if (msgContainer) {";
             echo "      msgContainer.classList.remove('show');";
             echo "      setTimeout(() => msgContainer.remove(), 500);";
             echo "    }";
             echo "  }, 5000);"; // Give internal errors a bit more time
             echo "</script>";
        }
        ?>

        <div class="top-actions">
            <a href="add_product.php" class="add-product-btn"><i class="fas fa-plus-circle"></i> Add New Product</a>
            <a href="admin_dashboard.php" class="back-dashboard-btn"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>

        <?php if (count($products) > 0): ?>
            <div class="product-table-container">
                <table class="products-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>ABV / Volume</th>
                            <th>Labels</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($product['product_id']); ?></td>
                                <td class="product-image-cell">
                                    <?php if (!empty($product['image_url'])): ?>
                                        <img src="/Drinkilla/<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                    <?php else: ?>
                                        <div class="no-image-placeholder">No Image</div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($product['name']); ?></td>
                                <td><?php echo htmlspecialchars($product['category']); ?></td>
                                <td class="product-price">₹<?php echo number_format($product['price'], 2); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($product['alcohol_percentage']); ?>% ABV<br>
                                    <?php echo htmlspecialchars($product['volume']); ?>ml
                                </td>
                                <td>
                                    <?php if ($product['is_bestseller']): ?>
                                        <span class="product-label bestseller-label">Bestseller</span>
                                    <?php endif; ?>
                                    <?php if ($product['is_new']): ?>
                                        <span class="product-label new-label">New</span>
                                    <?php endif; ?>
                                </td>
                                <td class="action-buttons">
                                    <a href="edit_product.php?id=<?php echo $product['product_id']; ?>" class="edit-btn"><i class="fas fa-edit"></i> Edit</a>
                                    <a href="delete_product.php?id=<?php echo $product['product_id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this product? This action cannot be undone.');"><i class="fas fa-trash-alt"></i> Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="no-products-message">No products found in the database. <a href="add_product.php">Add a new product</a> to get started.</p>
        <?php endif; ?>
    </div>
</body>
</html>