<?php
// control_panel/process_edit_product.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db_connection.php'; // Path to your database connection
require_once 'admin_auth.php'; // Include basic admin authentication

// Redirect target after processing
$redirect_page = 'products.php'; // Redirect to the product list page by default

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs
    $id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT);
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = filter_var($_POST['price'] ?? '', FILTER_VALIDATE_FLOAT);
    $alcohol_percentage = trim($_POST['alcohol_percentage'] ?? '');
    $volume = trim($_POST['volume'] ?? '');
    $image_url = trim($_POST['image_url'] ?? '');
    $is_bestseller = isset($_POST['is_bestseller']) ? 1 : 0;
    $is_new = isset($_POST['is_new']) ? 1 : 0;

    $errors = [];

    // Basic validation
    if ($id === false || $id <= 0) { $errors[] = "Invalid Product ID."; }
    if (empty($name)) { $errors[] = "Product Name is required."; }
    if (empty($category)) { $errors[] = "Category is required."; }
    if ($price === false || $price < 0) { $errors[] = "Valid Price is required."; }

    // Set redirect page back to edit form if validation fails for a specific product
    if ($id > 0) {
        $redirect_page = "edit_product.php?id=" . $id;
    }

    if (count($errors) > 0) {
        header("Location: " . $redirect_page . "&message=" . urlencode(implode("<br>", $errors)) . "&type=error");
        exit();
    }

    // Prepare SQL UPDATE statement
    $stmt = $conn->prepare("UPDATE products SET 
                            name = ?, 
                            category = ?, 
                            description = ?, 
                            price = ?, 
                            alcohol_percentage = ?, 
                            volume = ?, 
                            image_url = ?, 
                            is_bestseller = ?, 
                            is_new = ?,
                            updated_at = CURRENT_TIMESTAMP
                            WHERE id = ?");

    if ($stmt === false) {
        header("Location: " . $redirect_page . "&message=" . urlencode("Database error: Could not prepare statement.") . "&type=error");
        exit();
    }

    // Bind parameters
    $stmt->bind_param("sssdsssiii",
        $name,
        $category,
        $description,
        $price,
        $alcohol_percentage,
        $volume,
        $image_url,
        $is_bestseller,
        $is_new,
        $id // The ID for the WHERE clause
    );

    // Execute and check for success
    if ($stmt->execute()) {
        header("Location: products.php?message=" . urlencode("Product updated successfully!") . "&type=success"); // Redirect to product list on success
        exit();
    } else {
        error_log("Failed to update product ID " . $id . ": " . $stmt->error);
        header("Location: " . $redirect_page . "&message=" . urlencode("Failed to update product. Please try again.") . "&type=error");
        exit();
    }

    $stmt->close();
    $conn->close();

} else {
    // If accessed directly without POST request
    header("Location: products.php");
    exit();
}
?>