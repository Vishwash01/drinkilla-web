<?php
session_start(); // Make sure session_start() is the very first thing

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Path to db_connection.php: from ControlPannel/ go up one level (to Drinkilla/), then into 'includes/'
require_once 'db_connection.php';

// --- ADMIN AUTHENTICATION CHECK ---
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: /Drinkilla/ControlPannel/index.php?message=" . urlencode("Access denied. Please log in as an administrator.") . "&type=error");
    exit();
}
// --- END ADMIN AUTHENTICATION CHECK ---
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drinkila - Add New Product</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="admincss/admin_form_styles.css">
</head>
<body>
    <div class="container">
        <header class="page-header">
            <h1><i class="fas fa-plus-circle"></i> Add New Product</h1>
            <p>Fill in the details below to add a new product to your inventory.</p>
        </header>

        <?php
        // Display messages from process_add_product.php or internal errors
        if (isset($_GET['message'])) {
            $display_message = htmlspecialchars($_GET['message']);
            $display_type = isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'info';
            echo "<div class='message-container {$display_type} show'>";
            echo "  <i class='" . ($display_type == 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle') . "'></i>";
            echo "  <span>{$display_message}</span>";
            echo "</div>";
            // JavaScript to hide the message after a few seconds
            echo "<script>";
            echo "  setTimeout(() => {";
            echo "    const msgContainer = document.querySelector('.message-container');";
            echo "    if (msgContainer) {";
            echo "      msgContainer.classList.remove('show');"; // Trigger fade-out
            echo "      setTimeout(() => msgContainer.remove(), 500);"; // Remove from DOM after transition
            echo "    }";
            echo "  }, 3000);"; // Message disappears after 3 seconds
            echo "</script>";
        }
        ?>

        <form action="process_add_product.php" method="POST" enctype="multipart/form-data"> <div class="form-group">
                <label for="name">Product Name: <span class="required">*</span></label>
                <input type="text" id="name" name="name" placeholder="e.g., Johnnie Walker Black Label" required>
            </div>

            <div class="form-group">
                <label for="category">Category: <span class="required">*</span></label>
                <select id="category" name="category" required>
                    <option value="">Select Category</option>
                    <option value="Whisky">Whisky</option>
                    <option value="Beer">Beer</option>
                    <option value="Wine">Wine</option>
                    <option value="Vodka">Vodka</option>
                    <option value="Rum">Rum</option>
                    <option value="Brandy">Brandy</option>
                    <option value="Champagne">Champagne</option>
                    <option value="Cocktails">Cocktails</option>
                </select>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <textarea id="description" name="description" rows="5" placeholder="A detailed description of the product..."></textarea>
            </div>

            <div class="form-group">
                <label for="price">Price (₹): <span class="required">*</span></label>
                <input type="number" id="price" name="price" step="0.01" min="0" placeholder="e.g., 2500.00" required>
            </div>

            <div class="form-group">
                <label for="alcohol_percentage">Alcohol Percentage (e.g., 40%):</label>
                <input type="text" id="alcohol_percentage" name="alcohol_percentage" placeholder="e.g., 40.0, 5.5, N/A">
            </div>

            <div class="form-group">
                <label for="volume">Volume (e.g., 750ml):</label>
                <input type="text" id="volume" name="volume" placeholder="e.g., 750ml, 330ml, 1L">
            </div>

            <div class="form-group">
                <label for="image_url">Image URL:</label>
                <input type="text" id="image_url" name="image_url" placeholder="Optional: images/products/whisky.png">
                <p class="form-hint">Provide a relative path (e.g., `uploads/products/image.jpg`). Alternatively, you can implement file upload functionality here.</p>
            </div>

            <div class="checkbox-group">
                <input type="checkbox" id="is_bestseller" name="is_bestseller" value="1">
                <label for="is_bestseller">Mark as Bestseller</label>
            </div>

            <div class="checkbox-group">
                <input type="checkbox" id="is_new" name="is_new" value="1">
                <label for="is_new">Mark as New Product</label>
            </div>

            <div class="form-actions">
                <button type="submit" class="submit-btn"><i class="fas fa-save"></i> Add Product</button>
                <a href="products.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Product List</a>
            </div>
        </form>
    </div>
</body>
</html>