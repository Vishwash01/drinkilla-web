<?php
// control_panel/edit_product.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db_connection.php'; // Path to your database connection
require_once 'admin_auth.php'; // Include basic admin authentication

$product = null;
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($product_id > 0) {
    // Fetch existing product details
    $stmt = $conn->prepare("SELECT id, name, category, description, price, alcohol_percentage, volume, image_url, is_bestseller, is_new FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $product = $result->fetch_assoc();
    } else {
        // Product not found, redirect to product list with error
        header("Location: products.php?message=" . urlencode("Product not found.") . "&type=error");
        exit();
    }
    $stmt->close();
} else {
    // No ID provided, redirect to product list with error
    header("Location: products.php?message=" . urlencode("No product ID specified for editing.") . "&type=error");
    exit();
}

$conn->close(); // Close the database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Edit Product: <?php echo htmlspecialchars($product['name'] ?? ''); ?></title>
    <link rel="stylesheet" href="../CSS File/your-admin-styles.css">
    <style>
        /* Basic inline styles for the admin form (can be moved to your-admin-styles.css) */
        body {
            font-family: Arial, sans-serif;
            background-color: #2a2a2a;
            color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #1e1e1e;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.5);
        }
        h2 {
            text-align: center;
            color: #ff3e6c;
            margin-bottom: 25px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="number"],
        input[type="url"],
        textarea,
        select {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #555;
            border-radius: 5px;
            background-color: #333;
            color: #f5f5f5;
            font-size: 1rem;
        }
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        input[type="checkbox"] {
            margin-right: 10px;
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            margin-top: 15px;
        }
        button[type="submit"] {
            display: block;
            width: 100%;
            padding: 12px;
            background-color: #2196F3; /* Blue for Edit */
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }
        button[type="submit"]:hover {
            background-color: #0b7dda;
        }
        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: center;
        }
        .message.success {
            background-color: #4CAF50;
            color: white;
        }
        .message.error {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Product: <?php echo htmlspecialchars($product['name'] ?? ''); ?></h2>

        <?php
        // Display messages from process_edit_product.php
        if (isset($_GET['message'])) {
            $message = htmlspecialchars($_GET['message']);
            $type = isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'info';
            echo "<p class='message {$type}'>{$message}</p>";
        }
        ?>

        <form action="process_edit_product.php" method="POST">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id'] ?? ''); ?>">

            <div class="form-group">
                <label for="name">Product Name:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($product['name'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="category">Category:</label>
                <select id="category" name="category" required>
                    <option value="">Select Category</option>
                    <?php
                    $categories = ['Whisky', 'Beer', 'Wine', 'Vodka', 'Rum', 'Brandy', 'Champagne', 'Cocktails'];
                    foreach ($categories as $cat) {
                        $selected = ($product['category'] ?? '') === $cat ? 'selected' : '';
                        echo "<option value='{$cat}' {$selected}>{$cat}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <textarea id="description" name="description"><?php echo htmlspecialchars($product['description'] ?? ''); ?></textarea>
            </div>

            <div class="form-group">
                <label for="price">Price (₹):</label>
                <input type="number" id="price" name="price" step="0.01" min="0" value="<?php echo htmlspecialchars($product['price'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="alcohol_percentage">Alcohol Percentage (e.g., 40% ABV):</label>
                <input type="text" id="alcohol_percentage" name="alcohol_percentage" value="<?php echo htmlspecialchars($product['alcohol_percentage'] ?? ''); ?>">
            </div>

            <div class="form-group">
                <label for="volume">Volume (e.g., 750ml):</label>
                <input type="text" id="volume" name="volume" value="<?php echo htmlspecialchars($product['volume'] ?? ''); ?>">
            </div>

            <div class="form-group">
                <label for="image_url">Image URL (e.g., images/products/whisky.png):</label>
                <input type="text" id="image_url" name="image_url" value="<?php echo htmlspecialchars($product['image_url'] ?? ''); ?>" placeholder="images/products/example.png">
                <?php if (!empty($product['image_url'])): ?>
                    <br><img src="../<?php echo htmlspecialchars($product['image_url']); ?>" alt="Current Image" style="max-width: 100px; height: auto; margin-top: 10px; border: 1px solid #555; border-radius: 5px;">
                <?php endif; ?>
            </div>

            <div class="checkbox-group">
                <input type="checkbox" id="is_bestseller" name="is_bestseller" value="1" <?php echo ($product['is_bestseller'] ?? 0) ? 'checked' : ''; ?>>
                <label for="is_bestseller">Mark as Bestseller</label>
            </div>

            <div class="checkbox-group">
                <input type="checkbox" id="is_new" name="is_new" value="1" <?php echo ($product['is_new'] ?? 0) ? 'checked' : ''; ?>>
                <label for="is_new">Mark as New Product</label>
            </div>

            <button type="submit">Update Product</button>
        </form>
        <p style="text-align: center; margin-top: 20px;"><a href="products.php" style="color: #ffac30; text-decoration: none;">Back to Product List</a></p>
    </div>
</body>
</html>