<?php
// Database connection parameters
$servername = "localhost"; // Your database host
$username = "root";        // Your database username (e.g., root for XAMPP/WAMP)
$password = "";            // Your database password (empty for XAMPP/WAMP by default)
$dbname = "drink_drop";    // Your database name

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // In a production environment, you would log this error and show a generic message to the user.
    // For development, we'll die with the specific error.
    die("Database Connection Failed: " . $conn->connect_error);
}

// Optionally set the character set to UTF-8 for proper handling of various characters
$conn->set_charset("utf8mb4");

// Note: We don't close the connection here. It will be closed in individual scripts
// or automatically by PHP at the end of the script execution.
?>