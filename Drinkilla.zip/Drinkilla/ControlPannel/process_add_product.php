<?php
// control_panel/process_add_product.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Updated path to your database connection, now one level up from 'control_panel'
require_once 'db_connection.php'; 
// Updated path to your admin authentication file, within the SAME 'control_panel' folder
require_once 'admin_auth.php'; 

// Redirect target after processing (back to add_product.php in the SAME folder)
$redirect_page = 'add_product.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs (same as before)
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = filter_var($_POST['price'] ?? '', FILTER_VALIDATE_FLOAT);
    $alcohol_percentage = trim($_POST['alcohol_percentage'] ?? '');
    $volume = trim($_POST['volume'] ?? '');
    $image_url = trim($_POST['image_url'] ?? '');
    $is_bestseller = isset($_POST['is_bestseller']) ? 1 : 0;
    $is_new = isset($_POST['is_new']) ? 1 : 0;

    $errors = [];

    // Basic validation (same as before)
    if (empty($name)) { $errors[] = "Product Name is required."; }
    if (empty($category)) { $errors[] = "Category is required."; }
    if ($price === false || $price < 0) { $errors[] = "Valid Price is required."; }

    if (count($errors) > 0) {
        header("Location: " . $redirect_page . "?message=" . urlencode(implode("<br>", $errors)) . "&type=error");
        exit();
    }

    // Prepare SQL INSERT statement (same as before)
    $stmt = $conn->prepare("INSERT INTO products 
                            (name, category, description, price, alcohol_percentage, volume, image_url, is_bestseller, is_new) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if ($stmt === false) {
        header("Location: " . $redirect_page . "?message=" . urlencode("Database error: Could not prepare statement.") . "&type=error");
        exit();
    }

    // Bind parameters (same as before)
    $stmt->bind_param("sssdsssii",
        $name,
        $category,
        $description,
        $price,
        $alcohol_percentage,
        $volume,
        $image_url,
        $is_bestseller,
        $is_new
    );

    // Execute and check for success (same as before)
    if ($stmt->execute()) {
        header("Location: " . $redirect_page . "?message=" . urlencode("Product added successfully!") . "&type=success");
        exit();
    } else {
        error_log("Failed to add product: " . $stmt->error);
        header("Location: " . $redirect_page . "?message=" . urlencode("Failed to add product. Please try again.") . "&type=error");
        exit();
    }

    $stmt->close();
    $conn->close();

} else {
    // If accessed directly without POST request (same as before)
    header("Location: " . $redirect_page);
    exit();
}
?>