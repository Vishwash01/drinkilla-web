<?php
session_start();
// The path below assumes db_connection.php is in 'includes' folder, one level up from 'ControlPannel'.
// So, from ControlPannel/admin_login.php, you go up to Drinkilla/ then into includes/db_connection.php.
require_once 'db_connection.php'; 

$message = '';
$type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = htmlspecialchars(trim($_POST['username']));
    $password = $_POST['password']; // Plain password from form

    if (empty($username) || empty($password)) {
        $message = "Please enter both username and password.";
        $type = "error";
    } else {
        // Prepare statement to fetch admin user from 'admin_users' table
        $stmt = $conn->prepare("SELECT id, username, password, full_name FROM admin_users WHERE username = ?");
        if ($stmt === false) {
            $message = "Database error: " . $conn->error;
            $type = "error";
        } else {
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows == 1) {
                $admin_user = $result->fetch_assoc();

                // Verify the hashed password
                if (password_verify($password, $admin_user['password'])) {
                    // Password is correct, set admin-specific session variables
                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['admin_id'] = $admin_user['id'];
                    $_SESSION['admin_username'] = $admin_user['username'];
                    $_SESSION['admin_full_name'] = $admin_user['full_name'];

                    // *** IMPORTANT REDIRECTION FIX ***
                    // Use an absolute path from your web root for robust redirection.
                    // This assumes your project is in 'C:\xampp\htdocs\Drinkilla\'
                    // And admin_dashboard.php is in 'C:\xampp\htdocs\Drinkilla\ControlPannel\'
                    header("Location: /Drinkilla/ControlPannel/admin_dashboard.php?message=" . urlencode("Welcome, " . htmlspecialchars($admin_user['full_name']) . "!") . "&type=success");
                    exit();
                } else {
                    $message = "Invalid username or password.";
                    $type = "error";
                }
            } else {
                $message = "Invalid username or password.";
                $type = "error";
            }
            $stmt->close();
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drinkila - Admin Login</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="admincss/admin_login.css"/>
    <style>
        
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">Drinkila Admin</div>
        <div class="title">Admin Login</div>

        <?php if ($message): ?>
            <p class="form-message <?php echo $type; ?>"><?php echo $message; ?></p>
        <?php endif; ?>

        <form action="admin_login.php" method="POST">
            <div class="input-wrap">
                <i class="fas fa-user"></i>
                <input type="text" id="username" name="username" placeholder="Admin Username" required autocomplete="username">
            </div>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password" placeholder="Password" required autocomplete="current-password">
            </div>
            <button type="submit" class="btn">Log In</button>
        </form>

        <div class="note">
            <p>This login is for administrators only.</p>
        </div>
    </div>
</body>
</html>