<?php
// control_panel/delete_product.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db_connection.php'; // Path to your database connection
require_once 'admin_auth.php'; // Include basic admin authentication

// Redirect target after processing
$redirect_page = 'products.php';

if (isset($_GET['id'])) {
    $product_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

    if ($product_id === false || $product_id <= 0) {
        header("Location: " . $redirect_page . "?message=" . urlencode("Invalid product ID for deletion.") . "&type=error");
        exit();
    }

    // Prepare SQL DELETE statement
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");

    if ($stmt === false) {
        header("Location: " . $redirect_page . "?message=" . urlencode("Database error: Could not prepare statement for deletion.") . "&type=error");
        exit();
    }

    // Bind parameter
    $stmt->bind_param("i", $product_id);

    // Execute and check for success
    if ($stmt->execute()) {
        // Check if any row was actually deleted
        if ($stmt->affected_rows > 0) {
            header("Location: " . $redirect_page . "?message=" . urlencode("Product deleted successfully!") . "&type=success");
        } else {
            header("Location: " . $redirect_page . "?message=" . urlencode("Product not found or already deleted.") . "&type=error");
        }
        exit();
    } else {
        error_log("Failed to delete product ID " . $product_id . ": " . $stmt->error);
        header("Location: " . $redirect_page . "?message=" . urlencode("Failed to delete product. Please try again.") . "&type=error");
        exit();
    }

    $stmt->close();
    $conn->close();

} else {
    // If accessed directly without an ID
    header("Location: " . $redirect_page . "?message=" . urlencode("No product ID specified for deletion.") . "&type=error");
    exit();
}
?>