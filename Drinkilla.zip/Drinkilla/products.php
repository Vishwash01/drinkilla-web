<?php
include 'includes/db.php';
$sql = "SELECT * FROM products";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Our Liquor Selection | DrinkDrop</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header>
        <h1>BoozeExpress 🥃</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="cart.php">Cart</a>
        </nav>
    </header>

    <main>
        <h2>Our Liquor Selection</h2>
        <div class="product-grid">
            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                <div class="product-card">
                    <img src="assets/images/<?= $row['image'] ?>" alt="<?= $row['name'] ?>">
                    <h3><?= $row['name'] ?></h3>
                    <p>$<?= $row['price'] ?></p>
                    <button onclick="addToCart(<?= $row['id'] ?>)">Add to Cart</button>
                </div>
            <?php endwhile; ?>
        </div>
    </main>

    <script src="assets/js/script.js"></script>
</body>
</html>