<?php
// add_to_cart.php
session_start(); // Start the session to access $_SESSION['cart'] and $_SESSION['customer_id']

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/db_connection.php'; // Path to your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = filter_var($_POST['product_id'], FILTER_VALIDATE_INT);
    // Assuming quantity is always 1 when adding from product page
    // If you have a quantity input on the product page, retrieve it similarly:
    $quantity = 1; // Default to 1 for "Add to Cart" button

    if ($product_id === false || $product_id <= 0) {
        // Invalid product ID, redirect back to productdash with an error
        header('Location: productdash.php?message=' . urlencode('Invalid product ID.') . '&type=error');
        exit();
    }

    // --- START: DB CART LOGIC FOR LOGGED-IN USERS ---
    if (isset($_SESSION['customer_id'])) { // Check if user is logged in
        $customer_id = $_SESSION['customer_id'];

        // Fetch product details for database insertion (only essential ones if not already in carts table)
        // You might not need all details here if 'carts' only stores ID and quantity.
        // But if you plan to use 'name', 'price', etc. in 'carts' table directly, you'd fetch them here.
        // For now, we only need product_id, but keeping this part for future expansion if needed.
        $stmt_product_check = $conn->prepare("SELECT product_id FROM products WHERE product_id = ?"); // Simplified
        if ($stmt_product_check === false) {
            header('Location: productdash.php?message=' . urlencode('DB error preparing product check: ' . $conn->error) . '&type=error');
            exit();
        }
        $stmt_product_check->bind_param("i", $product_id);
        $stmt_product_check->execute();
        $result_product_check = $stmt_product_check->get_result();

        if ($result_product_check->num_rows === 0) {
            $stmt_product_check->close();
            $conn->close();
            header('Location: productdash.php?message=' . urlencode('Product not found.') . '&type=error');
            exit();
        }
        $stmt_product_check->close(); // Close this stmt early

        // Check if product already exists in the user's cart in the database
        $stmt_check_cart = $conn->prepare("SELECT quantity FROM carts WHERE user_id = ? AND product_id = ?");
        if ($stmt_check_cart === false) {
            header('Location: productdash.php?message=' . urlencode('DB error preparing cart check: ' . $conn->error) . '&type=error');
            exit();
        }
        $stmt_check_cart->bind_param("ii", $customer_id, $product_id);
        $stmt_check_cart->execute();
        $result_check_cart = $stmt_check_cart->get_result();

        if ($result_check_cart->num_rows > 0) {
            // Product already in cart, update quantity
            $row = $result_check_cart->fetch_assoc();
            $new_quantity = $row['quantity'] + $quantity; // Increment by current add quantity (default 1)

            $update_stmt = $conn->prepare("UPDATE carts SET quantity = ? WHERE user_id = ? AND product_id = ?");
            if ($update_stmt === false) {
                header('Location: productdash.php?message=' . urlencode('DB error preparing update: ' . $conn->error) . '&type=error');
                exit();
            }
            $update_stmt->bind_param("iii", $new_quantity, $customer_id, $product_id);
            if ($update_stmt->execute()) {
                $message = 'Product quantity updated in your cart!';
                header('Location: productdash.php?message=' . urlencode($message) . '&type=success');
                exit();
            } else {
                header('Location: productdash.php?message=' . urlencode('Failed to update product quantity in database cart: ' . $update_stmt->error) . '&type=error');
                exit();
            }
            $update_stmt->close();
        } else {
            // Product not in cart, insert new item
            $insert_stmt = $conn->prepare("INSERT INTO carts (user_id, product_id, quantity) VALUES (?, ?, ?)");
            if ($insert_stmt === false) {
                header('Location: productdash.php?message=' . urlencode('DB error preparing insert: ' . $conn->error) . '&type=error');
                exit();
            }
            $insert_stmt->bind_param("iii", $customer_id, $product_id, $quantity);
            if ($insert_stmt->execute()) {
                $message = 'Product added to your cart!';
                header('Location: productdash.php?message=' . urlencode($message) . '&type=success');
                exit();
            } else {
                header('Location: productdash.php?message=' . urlencode('Failed to add product to database cart: ' . $insert_stmt->error) . '&type=error');
                exit();
            }
            $insert_stmt->close();
        }
        $stmt_check_cart->close();
        // Database connection will be closed at the end of the script or by the auto-close from php_mysqli
        // No need to close $conn here, as it might be needed for other functions if this was part of a larger script.

    } else {
        // --- END: DB CART LOGIC ---

        // --- START: SESSION CART LOGIC FOR GUEST USERS (Your existing logic) ---
        // Fetch product details for session cart (needed for display if not fetching from DB later)
        $stmt_product = $conn->prepare("SELECT product_id, name, price, image_url, volume, alcohol_percentage FROM products WHERE product_id = ?");
        if ($stmt_product === false) {
            header('Location: productdash.php?message=' . urlencode('DB error preparing product fetch: ' . $conn->error) . '&type=error');
            exit();
        }
        $stmt_product->bind_param("i", $product_id);
        $stmt_product->execute();
        $result_product = $stmt_product->get_result();

        if ($result_product->num_rows === 1) {
            $product = $result_product->fetch_assoc();

            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }

            // Check if product is already in cart
            if (isset($_SESSION['cart'][$product_id])) {
                // If exists, just increment quantity
                $_SESSION['cart'][$product_id]['quantity']++;
                $message = htmlspecialchars($product['name']) . ' quantity updated in cart!';
            } else {
                // Add product to cart with quantity 1
                $_SESSION['cart'][$product_id] = [
                    'id' => $product['product_id'], // Corrected to product_id from your table
                    'name' => $product['name'],
                    'price' => $product['price'],
                    'image_url' => $product['image_url'],
                    'volume' => $product['volume'],
                    'alcohol_percentage' => $product['alcohol_percentage'],
                    'quantity' => 1
                ];
                $message = htmlspecialchars($product['name']) . ' added to cart!';
            }
            $stmt_product->close();
            // --- END: SESSION CART LOGIC ---

            header('Location: productdash.php?message=' . urlencode($message) . '&type=success');
            exit();

        } else {
            // Product not found in database (even for guest, needs to exist to be added)
            $stmt_product->close();
            header('Location: productdash.php?message=' . urlencode('Product not found.') . '&type=error');
            exit();
        }
    }
    // No need to close $conn here, as it's the end of the script for both branches.
    // PHP will automatically close the connection when the script finishes.
} else {
    // Not a POST request or product_id is missing
    header('Location: productdash.php');
    exit();
}
?>