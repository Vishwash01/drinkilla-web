<?php
session_start();
// Ensure this path is correct for your database connection file (e.g., db_connection.php)
require_once 'db_connection.php';

header('Content-Type: application/json'); // Set header for JSON response

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from the AJAX request
    $mobile_number = isset($_POST['mobileNumber']) ? trim($_POST['mobileNumber']) : '';
    $otp_entered = isset($_POST['otp']) ? trim($_POST['otp']) : '';

    // Basic validation
    if (empty($mobile_number) || empty($otp_entered)) {
        $response['message'] = 'Mobile number and OTP are required.';
        echo json_encode($response);
        exit();
    }

    // --- IMPORTANT: This is where you would normally implement your OTP generation and verification logic ---
    // For this example, we're simulating successful verification for *any* matching mobile number and a dummy OTP.
    // In a real system:
    // 1. You'd have a 'sent_otps' table or similar, storing OTPs sent to numbers with an expiry time.
    // 2. You'd fetch the expected OTP for $mobile_number from that table.
    // 3. You'd compare $otp_entered with the stored OTP.
    // 4. You'd check if the OTP is expired.

    // FOR DEMONSTRATION PURPOSES ONLY: Assuming a dummy OTP '123456' for any valid registered mobile number.
    // YOU MUST REPLACE THIS WITH ACTUAL OTP VERIFICATION LOGIC.
    if ($otp_entered !== '123456') { // Replace '123456' with logic to fetch and compare actual sent OTP
        $response['message'] = 'Invalid OTP. Please try again.';
        echo json_encode($response);
        exit();
    }

    // --- If OTP is valid, proceed to log the user in ---
    // Check if the mobile number exists in your 'customer' table
    $stmt = $conn->prepare("SELECT id, full_name, email FROM customer WHERE mobile_number = ?");
    if ($stmt === false) {
        $response['message'] = 'Database error during user lookup: ' . $conn->error;
        echo json_encode($response);
        exit();
    }
    $stmt->bind_param("s", $mobile_number);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Set session variables upon successful login
        $_SESSION['customer_id'] = $user['id'];
        $_SESSION['customer_name'] = $user['full_name']; // Storing full_name for display
        $_SESSION['customer_email'] = $user['email'];

        // --- START: CART MERGING LOGIC ---
        // Check if there are any items in the guest session cart
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            $customer_id = $_SESSION['customer_id']; // Get the freshly set customer_id

            foreach ($_SESSION['cart'] as $product_id => $item_details) {
                $quantity = intval($item_details['quantity']); // Ensure quantity is an integer

                // Check if this product already exists in the user's permanent database cart
                $stmt_check_cart = $conn->prepare("SELECT quantity FROM carts WHERE user_id = ? AND product_id = ?");
                if ($stmt_check_cart === false) {
                    // Log the error, but don't halt the login process
                    error_log("Cart merge error (prepare check): " . $conn->error);
                    continue; // Skip to next item
                }
                $stmt_check_cart->bind_param("ii", $customer_id, $product_id);
                $stmt_check_cart->execute();
                $result_check_cart = $stmt_check_cart->get_result();

                if ($result_check_cart->num_rows > 0) {
                    // Product exists in DB cart, update its quantity
                    $row = $result_check_cart->fetch_assoc();
                    $new_quantity = $row['quantity'] + $quantity;

                    $stmt_update_cart = $conn->prepare("UPDATE carts SET quantity = ? WHERE user_id = ? AND product_id = ?");
                    if ($stmt_update_cart === false) {
                        error_log("Cart merge error (prepare update): " . $conn->error);
                        continue;
                    }
                    $stmt_update_cart->bind_param("iii", $new_quantity, $customer_id, $product_id);
                    $stmt_update_cart->execute();
                    $stmt_update_cart->close();
                } else {
                    // Product does NOT exist in DB cart, insert new item
                    $stmt_insert_cart = $conn->prepare("INSERT INTO carts (user_id, product_id, quantity) VALUES (?, ?, ?)");
                    if ($stmt_insert_cart === false) {
                        error_log("Cart merge error (prepare insert): " . $conn->error);
                        continue;
                    }
                    $stmt_insert_cart->bind_param("iii", $customer_id, $product_id, $quantity);
                    $stmt_insert_cart->execute();
                    $stmt_insert_cart->close();
                }
                $stmt_check_cart->close();
            }

            // After merging all items from session cart to database, clear the session cart
            unset($_SESSION['cart']);
        }
        // --- END: CART MERGING LOGIC ---

        $response['success'] = true;
        $response['message'] = 'Login successful!';
        $response['redirect'] = 'productdash.php?message=' . urlencode('Welcome, ' . htmlspecialchars($user['full_name']) . '!') . '&type=success';
    } else {
        $response['message'] = 'User not found for this mobile number after OTP verification.';
    }
    $stmt->close();

} else {
    $response['message'] = 'Invalid request method.';
}

echo json_encode($response);
$conn->close();
?>