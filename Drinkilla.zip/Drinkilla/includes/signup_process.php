<?php
// Include the database connection file using __DIR__ for a reliable path
require_once __DIR__ . '/db_connection.php';

// Define the page to redirect to after successful signup (the sign-in page)
// This path needs to go UP one directory from 'includes' to the root 'Drinkilla' folder
$redirect_on_success_page = "../login.php"; // Pointing to your login.php file

// Define the page to redirect to on failure (i.e., back to the signup form)
$signup_page = "../signup.php"; // This remains the same for errors/validation failures

// Check if the form was submitted via POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize input data from $_POST superglobal
    $fullName = trim($_POST['fullName'] ?? '');
    $mobileNumber = trim($_POST['mobileNumber'] ?? '');
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $plainPassword = $_POST['password'] ?? ''; // Get the plain password
    $termsAccepted = isset($_POST['termsAccepted']) ? true : false;

    $errors = []; // Array to store validation errors

    // Server-side validation (this is crucial and cannot be removed)
    if (empty($fullName)) {
        $errors[] = "Full Name is required.";
    }
    if (empty($mobileNumber)) {
        $errors[] = "Mobile Number is required.";
    } elseif (!preg_match('/^\d{10}$/', $mobileNumber)) {
        $errors[] = "Mobile number must be a 10-digit number.";
    }
    if (empty($email)) {
        $errors[] = "Email Address is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }
    if (empty($plainPassword)) {
        $errors[] = "Password is required.";
    } elseif (strlen($plainPassword) < 6) {
        $errors[] = "Password must be at least 6 characters long.";
    }
    if (!$termsAccepted) {
        $errors[] = "You must agree to the terms & privacy policy.";
    }

    if (count($errors) > 0) {
        // If there are validation errors, redirect back with all messages
        header("Location: " . $signup_page . "?message=" . urlencode(implode("<br>", $errors)) . "&type=error");
        exit();
    }

    // Hash the password for security
    $hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);

    // Prepare and bind SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO customer (full_name, mobile_number, email, password) VALUES (?, ?, ?, ?)");
    
    if ($stmt === false) {
        header("Location: " . $signup_page . "?message=" . urlencode("Database error: Could not prepare statement.") . "&type=error");
        exit();
    }

    $stmt->bind_param("ssss", $fullName, $mobileNumber, $email, $hashedPassword);

    try {
        if ($stmt->execute()) {
            // SUCCESS: Redirect to login page
            header("Location: " . $redirect_on_success_page . "?message=" . urlencode("Account created successfully! You can now sign in.") . "&type=success");
            exit();
        }
    } catch (mysqli_sql_exception $e) { // Catch MySQLi exceptions
        $errorMessage = "";

        if ($e->getCode() == 1062) { // MySQL error code for duplicate entry
            if (strpos($e->getMessage(), 'mobile_number') !== false) {
                $errorMessage = "Mobile number is already registered.";
            } elseif (strpos($e->getMessage(), 'email') !== false) {
                $errorMessage = "Email address is already registered.";
            } else {
                $errorMessage = "Registration failed: A duplicate entry was found.";
            }
        } else {
            // Handle other database errors
            $errorMessage = "Registration failed due to a server error: " . $e->getMessage();
            // Consider logging $e->getMessage() to a server log for real applications
        }

        header("Location: " . $signup_page . "?message=" . urlencode($errorMessage) . "&type=error");
        exit();
    }
    // --- End of try-catch block ---

    $stmt->close();
    $conn->close();

} else {
    // If someone accesses signup_process.php directly without POST
    header("Location: " . $signup_page);
    exit();
}
     
?>