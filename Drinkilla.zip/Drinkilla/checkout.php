<?php
session_start();
error_reporting(E_ALL); // Enable error reporting for debugging
ini_set('display_errors', 1); // Display errors for debugging

require_once 'includes/db_connection.php'; // Your database connection file

// Initialize message variables
$message = '';
$type = '';

// Check if cart is empty at the very beginning
// If cart is empty, redirect to cart.php with an informational message.
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: cart.php?message=' . urlencode('Your cart is empty. Please add items before checking out.') . '&type=info');
    exit();
}

// Prepare cart items for display and calculate subtotal using data directly from session
// $_SESSION['cart'] is expected to have 'name', 'price', and 'quantity'
$cart_items_for_display = $_SESSION['cart'];
$subtotal = 0;
foreach ($cart_items_for_display as $product_id => $item) {
    // Ensure 'price' and 'quantity' exist from cart.php's population
    $item_price = isset($item['price']) ? (float)$item['price'] : 0;
    $item_quantity = isset($item['quantity']) ? (int)$item['quantity'] : 0;
    $subtotal += ($item_price * $item_quantity);
    // If 'name' is not consistently in session, you'd need to fetch it here for display.
    // For now, assuming cart.php populates it.
}

// --- Pre-fill form for logged-in users ---
$customer_name = '';
$customer_email = '';
$customer_phone = '';
$customer_id = null; // Initialize to null for guests (for 'user_id' in orders table)

if (isset($_SESSION['customer_id'])) { // Assuming 'customer_id' is the session key for user ID
    $customer_id = $_SESSION['customer_id'];
    $stmt_user = $conn->prepare("SELECT full_name, email, mobile_number FROM customer WHERE id = ?");
    if ($stmt_user) {
        $stmt_user->bind_param("i", $customer_id);
        $stmt_user->execute();
        $result_user = $stmt_user->get_result();
        if ($user_data = $result_user->fetch_assoc()) {
            $customer_name = htmlspecialchars($user_data['full_name']);
            $customer_email = htmlspecialchars($user_data['email']);
            $customer_phone = htmlspecialchars($user_data['mobile_number']);
        }
        $stmt_user->close();
    }
}

// --- Process form submission when user clicks "Place Order" ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Re-validate and re-sanitize inputs from POST data
    $customer_name_post = htmlspecialchars(trim($_POST['customer_name']));
    $customer_email_post = filter_var(trim($_POST['customer_email']), FILTER_SANITIZE_EMAIL);
    $customer_phone_post = htmlspecialchars(trim($_POST['customer_phone']));
    $shipping_address_post = htmlspecialchars(trim($_POST['shipping_address']));
    $shipping_city_post = htmlspecialchars(trim($_POST['shipping_city']));
    $shipping_state_post = htmlspecialchars(trim($_POST['shipping_state']));
    $shipping_zip_post = htmlspecialchars(trim($_POST['shipping_zip']));
    
    // Use the calculated subtotal as the order_total for database insertion
    $order_total = $subtotal; 

    $errors = [];

    // Server-side Validation
    if (empty($customer_name_post)) $errors[] = "Full Name is required.";
    if (empty($customer_email_post) || !filter_var($customer_email_post, FILTER_VALIDATE_EMAIL)) $errors[] = "Valid Email is required.";
    if (empty($customer_phone_post)) $errors[] = "Phone Number is required.";
    if (empty($shipping_address_post)) $errors[] = "Street Address is required.";
    if (empty($shipping_city_post)) $errors[] = "City is required.";
    if (empty($shipping_state_post)) $errors[] = "State is required.";
    if (empty($shipping_zip_post)) $errors[] = "ZIP Code is required.";
    
    // Final check for cart emptiness right before transaction
    if (empty($cart_items_for_display)) {
        $errors[] = "Your cart became empty during checkout. Please add items again.";
    }

    if (empty($errors)) {
        $conn->begin_transaction(); // Start a database transaction for atomicity
        try {
            // 1. Insert order into 'orders' table
            // Ensure your 'orders' table has 'user_id', 'total_amount', 'customer_name', etc., and 'order_date' as DATETIME.
            $stmt_order = $conn->prepare("INSERT INTO orders (user_id, total_amount, customer_name, customer_email, customer_phone, shipping_address, shipping_city, shipping_state, shipping_zip, status, order_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', NOW())");
            
            // `idsssssss` : i (user_id INT), d (total_amount DECIMAL/DOUBLE), s (7 strings for customer/shipping info)
            // This matches the 9 '?' placeholders in the SQL query.
            $stmt_order->bind_param("idsssssss", 
                $customer_id, // Will be NULL for guests, or customer_id for logged-in users
                $order_total, 
                $customer_name_post, 
                $customer_email_post, 
                $customer_phone_post, 
                $shipping_address_post, 
                $shipping_city_post, 
                $shipping_state_post, 
                $shipping_zip_post
            );
            $stmt_order->execute();
            $order_id = $conn->insert_id; // Get the ID of the newly created order
            $stmt_order->close();

            // 2. Insert order items into 'order_items' table
            // Ensure your 'order_items' table has 'order_id', 'product_id', 'quantity', 'price_at_purchase'.
            $stmt_item = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) VALUES (?, ?, ?, ?)");
            foreach ($cart_items_for_display as $product_id => $item) {
                $item_quantity = (int)($item['quantity'] ?? 0);
                $price_at_purchase = (float)($item['price'] ?? 0); // Use price directly from session cart (price at time of adding to cart)
                
                $stmt_item->bind_param("iiid", $order_id, $product_id, $item_quantity, $price_at_purchase);
                $stmt_item->execute();
            }
            $stmt_item->close();

            // 3. Optional: Update product inventory (decrement stock quantity)
            // Uncomment this section if your 'products' table has a 'stock_quantity' column
            /*
            $stmt_stock_update = $conn->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ? AND stock_quantity >= ?");
            foreach ($cart_items_for_display as $product_id => $item) {
                $item_quantity = (int)($item['quantity'] ?? 0);
                $stmt_stock_update->bind_param("iii", $item_quantity, $product_id, $item_quantity);
                $stmt_stock_update->execute();
                if ($stmt_stock_update->affected_rows === 0) {
                    // This means stock was insufficient or product_id was invalid
                    throw new Exception("Insufficient stock for product ID " . $product_id . ". Please reduce quantity.");
                }
            }
            $stmt_stock_update->close();
            */

            $conn->commit(); // Commit the transaction if all operations were successful
            
            // 4. Clear carts after successful order placement
            unset($_SESSION['cart']); // Clear the session cart

            // If user is logged in, also clear their persistent database cart (if you implemented one)
            if (isset($_SESSION['customer_id'])) {
                $stmt_clear_db_cart = $conn->prepare("DELETE FROM carts WHERE user_id = ?");
                $stmt_clear_db_cart->bind_param("i", $_SESSION['customer_id']);
                $stmt_clear_db_cart->execute();
                $stmt_clear_db_cart->close();
            }

            // 5. Redirect to order confirmation page
            header('Location: order_confirmation.php?order_id=' . $order_id . '&message=' . urlencode("Your order has been placed successfully!") . '&type=success');
            exit();

        } catch (Exception $e) {
            $conn->rollback(); // Rollback all changes if any error occurred within the transaction
            $message = "Error placing order: " . $e->getMessage();
            $type = "error";
            error_log("Order placement failed: " . $e->getMessage()); // Log the actual error for server-side debugging
        }
    } else {
        // If validation errors occurred, display them
        $message = implode('<br>', $errors);
        $type = "error";
    }
    // If there were errors, we redirect back to checkout.php with the message
    // so the message can be displayed using GET parameters.
    header('Location: checkout.php?message=' . urlencode($message) . '&type=' . urlencode($type));
    exit();
}

// Close DB connection after all possible operations (POST or initial page load)
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drinkila - Checkout</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Your CSS is perfectly fine and not modified. It is included here for completeness. */
        :root {
            --primary: #FF7E33;
            --secondary: #1A1A1A;
            --accent: #FF7E33;
            --light: #2D2D2D;
            --dark: #FFFFFF;
            --gray: #AAAAAA;
            --card-bg: #2D2D2D;
            --text-dark: #FFFFFF;
            --text-light: #1A1A1A;
            --success: #4CAF50;
            --error: #F44336;
            --info: #2196F3;
            --border-radius: 12px;
            --border-radius-sm: 8px;
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.3);
            --shadow-md: 0 4px 12px rgba(0,0,0,0.4);
            --shadow-lg: 0 8px 24px rgba(0,0,0,0.5);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--secondary);
            color: var(--text-dark);
            line-height: 1.5;
            padding-bottom: 20px;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 15px;
        }

        /* Header */
        .checkout-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light);
        }

        .checkout-header h1 {
            color: var(--primary);
            font-size: 1.8rem;
            margin-bottom: 8px;
        }

        .checkout-header p {
            color: var(--gray);
            font-size: 0.9rem;
        }

        /* Checkout Layout */
        .checkout-grid {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        /* Order Summary - Now comes first in mobile */
        .order-summary {
            background: var(--card-bg);
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            order: 1; /* Makes it appear first */
        }

        .order-summary-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .order-summary h2 {
            color: var(--primary);
            font-size: 1.3rem;
        }

        .edit-cart-btn {
            color: var(--primary);
            text-decoration: none;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .order-items {
            margin-bottom: 15px;
        }

        .order-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #333;
            font-size: 0.95rem;
        }

        .order-item:last-child {
            border-bottom: none;
        }

        .order-item-name {
            font-weight: 500;
        }

        .order-item-quantity {
            color: var(--gray);
            font-size: 0.85rem;
        }

        .order-total {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 2px solid var(--light);
            font-size: 1.1rem;
            font-weight: 600;
        }

        /* Checkout Form */
        .checkout-form {
            background: var(--card-bg);
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            order: 2;
        }

        .form-section {
            margin-bottom: 20px;
        }

        .form-section h2 {
            color: var(--primary);
            font-size: 1.3rem;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-size: 0.9rem;
            color: var(--gray);
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            background: var(--light);
            border: 1px solid #444;
            border-radius: var(--border-radius-sm);
            color: var(--text-dark);
            font-size: 0.95rem;
            transition: var(--transition);
        }

        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 126, 51, 0.2);
        }

        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }

        /* Buttons */
        .button-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-top: 20px;
        }

        .btn {
            display: inline-block;
            padding: 14px;
            background: var(--primary);
            color: var(--text-dark);
            border: none;
            border-radius: var(--border-radius-sm);
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            text-align: center;
            text-decoration: none;
        }

        .btn:hover {
            background: #e66a2a;
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .btn-secondary {
            background: var(--light);
            color: var(--text-dark);
            border: 1px solid #444;
        }

        .btn-secondary:hover {
            background: #3a3a3a;
        }

        /* Message */
        .message-container {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            padding: 12px 24px;
            border-radius: 50px;
            text-align: center;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            max-width: 90%;
            z-index: 110;
            box-shadow: var(--shadow-md);
            animation: slideDown 0.3s ease-out;
            opacity: 0;
            visibility: hidden;
        }
        
        .message-container.show {
            opacity: 1;
            visibility: visible;
        }
        
        .message-container i {
            font-size: 18px;
        }
        
        .message-container.success {
            background-color: var(--primary);
            color: var(--text-dark);
            border: 1px solid var(--primary);
        }
        
        .message-container.error {
            background-color: var(--secondary);
            color: var(--error);
            border: 1px solid var(--error);
        }
        
        @keyframes slideDown {
            from {
                transform: translateX(-50%) translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateX(-50%) translateY(0);
                opacity: 1;
            }
        }

        /* Desktop View */
        @media (min-width: 768px) {
            .container {
                padding: 30px;
            }

            .checkout-header h1 {
                font-size: 2.2rem;
            }

            .checkout-grid {
                flex-direction: row;
                gap: 30px;
            }

            .order-summary {
                flex: 1;
                order: 2; /* Reverts to original order on desktop */
                position: sticky;
                top: 20px;
                height: fit-content;
            }

            .checkout-form {
                flex: 2;
                order: 1;
            }

            .button-group {
                flex-direction: row;
            }

            .btn,
            .btn-secondary {
                flex: 1;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="checkout-header">
            <h1><i class="fas fa-cocktail"></i> Drinkila Checkout</h1>
            <p>Complete your order with premium liquor delivery</p>
        </header>

        <?php
        // Display messages from GET parameters after redirection
        if (isset($_GET['message'])) {
            $display_message = htmlspecialchars($_GET['message']);
            $display_type = isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'info';
            echo "<div class='message-container {$display_type} show'>";
            echo "  <i class='" . ($display_type == 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle') . "'></i>";
            echo "  <span>{$display_message}</span>";
            echo "</div>";
            // JavaScript to hide the message after a few seconds
            echo "<script>";
            echo "  setTimeout(() => {";
            echo "    const msgContainer = document.querySelector('.message-container');";
            echo "    if (msgContainer) {";
            echo "      msgContainer.classList.remove('show');";
            // Optionally remove the element from DOM after fade out
            echo "      setTimeout(() => msgContainer.remove(), 500);"; // Wait for CSS transition
            echo "    }";
            echo "  }, 3000);";
            echo "</script>";
        }
        ?>

        <div class="checkout-grid">
            <div class="order-summary">
                <div class="order-summary-header">
                    <h2><i class="fas fa-receipt"></i> Order Summary</h2>
                    <a href="cart.php" class="edit-cart-btn">
                        <i class="fas fa-edit"></i> Edit Cart
                    </a>
                </div>
                <div class="order-items">
                    <?php if (!empty($cart_items_for_display)): ?>
                        <?php foreach ($cart_items_for_display as $product_id => $item): ?>
                            <div class="order-item">
                                <div>
                                    <span class="order-item-name"><?php echo htmlspecialchars($item['name'] ?? 'Unknown Product'); ?></span>
                                    <span class="order-item-quantity">× <?php echo htmlspecialchars($item['quantity'] ?? 0); ?></span>
                                </div>
                                <div>₹<?php echo number_format(($item['price'] ?? 0) * ($item['quantity'] ?? 0), 2); ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Your cart is empty.</p>
                    <?php endif; ?>
                </div>
                <div class="order-total">
                    <span>Total:</span>
                    <span>₹<?php echo number_format($subtotal, 2); ?></span>
                </div>
            </div>

            <div class="checkout-form">
                <form action="checkout.php" method="POST">
                    <div class="form-section">
                        <h2><i class="fas fa-user"></i> Contact Information</h2>
                        <div class="form-group">
                            <label for="customer_name">Full Name</label>
                            <input type="text" id="customer_name" name="customer_name" value="<?php echo $customer_name; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="customer_email">Email</label>
                            <input type="email" id="customer_email" name="customer_email" value="<?php echo $customer_email; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="customer_phone">Phone Number</label>
                            <input type="text" id="customer_phone" name="customer_phone" value="<?php echo $customer_phone; ?>" required>
                        </div>
                    </div>

                    <div class="form-section">
                        <h2><i class="fas fa-truck"></i> Shipping Address</h2>
                        <div class="form-group">
                            <label for="shipping_address">Street Address</label>
                            <textarea id="shipping_address" name="shipping_address" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="shipping_city">City</label>
                            <input type="text" id="shipping_city" name="shipping_city" required>
                        </div>
                        <div class="form-group">
                            <label for="shipping_state">State</label>
                            <input type="text" id="shipping_state" name="shipping_state" required>
                        </div>
                        <div class="form-group">
                            <label for="shipping_zip">ZIP Code</label>
                            <input type="text" id="shipping_zip" name="shipping_zip" required>
                        </div>
                    </div>

                    <div class="button-group">
                        <button type="submit" class="btn">Place Order</button>
                        <a href="productdash.php" class="btn btn-secondary">Cancel Order</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>