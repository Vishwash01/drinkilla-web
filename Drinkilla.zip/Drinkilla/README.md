# drinkilla-web
The codebase behind Drinkilla's refreshing online shop. Built with PHP, this project covers everything from product display and cart management to secure order processing and user verification.
# Drinkilla - Your Refreshing Online Beverage Destination

## 🍹 Project Overview

Welcome to the **Drinkilla** e-commerce platform! This project embodies a robust, PHP-driven online store meticulously crafted to deliver a delightful and efficient experience for purchasing your favorite beverages. Our mission is to seamlessly connect customers with a diverse catalog of refreshing drinks, facilitating every step from discovery to a secure and smooth checkout process.

We've prioritized an intuitive user interface alongside a solid, maintainable backend infrastructure. This ensures that core e-commerce functionalities operate flawlessly, guiding users through a pleasant journey from browsing enticing options to receiving their order confirmation.

## ✨ Key Features

This platform is packed with essential features designed for a modern e-commerce experience:

* **Dynamic Product Catalog:** Explore a wide and ever-growing assortment of beverages. Each product is presented with rich details, captivating images, and accurate pricing, all responsively displayed to look great on any device, from desktops to smartphones.
* **Intuitive Shopping Cart:** A user-friendly cart experience allows customers to easily add new items, adjust quantities of existing products, or remove items they no longer wish to purchase before proceeding to checkout.
* **Secure & Streamlined Checkout Process:** We've engineered a clear, step-by-step checkout flow that securely gathers necessary shipping and contact information, ensuring all details are ready for order placement.
* **Comprehensive User Management:** Dedicated functionalities for new customer registration and secure login for returning users, providing a personalized shopping experience.
* **Robust OTP Verification System:** Elevate security for critical user actions, such as account registration or finalizing an order, through a reliable One-Time Password (OTP) verification mechanism delivered via email or SMS.
* **Instant Order Confirmation:** After a successful purchase, users receive a clear and concise summary of their order, confirming their transaction and providing peace of mind.
* **Personalized User Settings Page:** A clean, responsive interface empowers users to effortlessly manage their account details, privacy preferences, and notification settings.
* **Persistent Data Storage:** A well-structured database schema ensures all vital information—including user profiles, product listings, active shopping carts, placed orders, and temporary OTPs—is securely stored and readily accessible.

## 🛠️ Technologies Used

This project leverages a powerful and widely adopted technology stack:

* **Backend Language:** PHP (Robust, server-side scripting)
    * **Database Management:** MySQL (Relational database for data storage)
    * **Database Interaction:** PDO (PHP Data Objects for secure and efficient database connections)
* **Frontend Technologies:**
    * **HTML5:** For semantic and structured web content.
    * **CSS3:** For modern, responsive, and aesthetically pleasing styling across all devices.
    * **Font Awesome:** A versatile icon library to enhance user interface elements.
    * **Google Fonts:** Utilizing the 'Poppins' typeface for a clean and contemporary typographical aesthetic.
* **Third-Party Services (Essential Integrations):**
    * **SMS/Email API:** Integration with a reliable service (e.g., Twilio, Fast2SMS, MSG91) is crucial for delivering OTPs to users for verification.

## 🚀 Getting Started

To set up the Drinkilla e-commerce project on your local development environment, please follow these instructions carefully.

### Prerequisites

Before you begin, ensure your system meets the following requirements:

* **Web Server:** Apache or Nginx (configured to serve PHP files).
* **PHP:** Version 7.4 or higher (ensuring compatibility with modern PHP features and security).
* **MySQL:** A running MySQL database server instance.
* **Git:** Installed on your system for cloning the project repository.

### Installation Steps

1.  **Clone the Repository:**
    Start by cloning the Drinkilla project from GitHub to your local machine:
    ```bash
    git clone [https://github.com/YourGitHubUsername/drinkilla-ecommerce.git](https://github.com/YourGitHubUsername/drinkilla-ecommerce.git)
    # Navigate into your project directory
    cd drinkilla-ecommerce
    ```
    (Remember to replace `YourGitHubUsername` with your actual GitHub username.)

2.  **Database Setup:**
    * **Create a Database:** Access your MySQL server (via phpMyAdmin, MySQL Workbench, or the command line) and create a new database. A suitable name would be `drinkilla_db`.
    * **Import Schema:** You will find a dedicated SQL file (e.g., `drink_drop.sql`) in the root of this repository. Import this file into the `drink_drop` database you just created. This will set up all the necessary tables, including `users`, `otp_verifications`, and any other tables required for products, carts, and orders.
    * **Verify Tables:** After importing, confirm that tables like `users` and `otp_verifications` (and others) are present in your `drinkilla_db`.

3.  **Configure Database Connection:**
    * Locate the `db_connection.php` file within the project directory.
    * Open this file and update the placeholder credentials to match your MySQL database setup:
        ```php
        <?php
        // db_connection.php
        $host = 'localhost';
        $dbname = 'drink_drop'; // <--- Your database name
        $username = 'root';      // <--- Your MySQL username
        $password = ''; // <--- Your MySQL password

        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
        ?>
        ```

4.  **Web Server Deployment:**
    * Move the entire `drinkilla-ecommerce` project folder into your web server's document root. Common locations include `htdocs` for Apache (XAMPP/WAMP) or `www` for Nginx.
    * Ensure your web server is running and properly configured to process `.php` files.

5.  **Integrate OTP Sending API:**
    * **Choose a Provider:** Select an SMS/Email API provider (e.g., Twilio, Fast2SMS, MSG91). You'll need to sign up for an account and obtain your API credentials (e.g., API Key, API Secret, Sender ID).
    * **Modify `send_otp.php`:** Open the `send_otp.php` file. Inside this file, you will find a commented-out section for API integration. Replace this placeholder with the actual code provided by your chosen API service. This typically involves installing their PHP SDK via Composer or making direct HTTP requests (e.g., using `cURL`) with your credentials and the generated OTP.

## 🤝 Contributing

We warmly welcome contributions to the Drinkilla project! Your ideas and efforts can help make this platform even better. If you have suggestions for improvements, new feature implementations, or bug fixes, please consider:

1.  **Forking the Repository:** Create your own copy of the project.
2.  **Creating a New Branch:** Make a dedicated branch for your changes (e.g., `git checkout -b feature/add-dark-mode` or `fix/otp-bug`).
3.  **Committing Your Changes:** Write clear and concise commit messages (`git commit -m 'Feat: Implemented dark mode toggle'`).
4.  **Pushing to Your Branch:** Upload your changes to your forked repository (`git push origin feature/add-dark-mode`).
5.  **Opening a Pull Request:** Submit a Pull Request from your branch to our `main` branch, detailing your changes.

## 📄 License

This project is open-source and distributed under the **MIT License**. For more details, see the `LICENSE` file in the repository root.

## 📞 Contact

For any questions, feedback, or further discussion, please feel free to reach out:

* **Your Name: Vishwash Upadhyay ** [vishwashofficial1@gmail.com]
* **Project Link:** [](https://github.com/Vishwash01/drinkilla-web/tree/main)