<?php
session_start();
// Enable error reporting for debugging. You might want to disable this in production.
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/db_connection.php'; // Your database connection file

if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php?message=" . urlencode("Please log in to access your account.") . "&type=error");
    exit();
}

$customer_id = $_SESSION['customer_id'];
$customer_name = isset($_SESSION['customer_name']) ? htmlspecialchars($_SESSION['customer_name']) : 'Customer';

// Fetch customer details
$customer_details = null;
// Assuming 'id' is the primary key for the customer table, as used in session and redirect
$stmt_customer = $conn->prepare("SELECT full_name, mobile_number, email, created_at FROM customer WHERE id = ?");
if ($stmt_customer) {
    $stmt_customer->bind_param("i", $customer_id);
    $stmt_customer->execute();
    $result_customer = $stmt_customer->get_result();
    if ($result_customer->num_rows > 0) {
        $customer_details = $result_customer->fetch_assoc();
    } else {
        // Handle case where customer details are not found (e.g., deleted account)
        error_log("Customer ID " . $customer_id . " not found in database.");
    }
    $stmt_customer->close();
} else {
    error_log("Failed to prepare statement for customer details: " . $conn->error);
}

// NOTE: The order fetching PHP code has been removed from this file.
// It should be moved to 'order_history.php' if you plan to create that page.

// The getOrderItems function is no longer needed in this file since orders are not displayed here.
// You will need to move it to 'order_history.php' if you use it there.
/*
function getOrderItems($order_id, $conn) {
    $items = [];
    $stmt = $conn->prepare("SELECT p.name, oi.quantity, oi.price_at_purchase FROM order_items oi JOIN products p ON oi.product_id = p.product_id WHERE oi.order_id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
        $stmt->close();
    } else {
        error_log("Failed to prepare statement for order items (ID: " . $order_id . "): " . $conn->error);
    }
    return $items;
}
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - Drinkila</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="CSS File/my_account_styles.css">
</head>
<body>
    <div class="container">
        <header class="account-header">
            <button class="back-btn" onclick="window.location.href='productdash.php'">
                <i class="fas fa-arrow-left"></i>
            </button>
            <h1><i class="fas fa-user-circle"></i> Welcome, <?php echo $customer_name; ?>!</h1>
            <a href="logout.php" class="top-logout-btn">
                <i class="fas fa-sign-out-alt"></i> <span class="logout-text">Logout</span>
            </a>
        </header>

        <?php if (isset($_GET['message'])): ?>
            <div class="message-box <?php echo htmlspecialchars($_GET['type'] ?? 'info'); ?>">
                <i class="fas fa-<?php
                    echo $_GET['type'] == 'success' ? 'check-circle' :
                         ($_GET['type'] == 'error' ? 'exclamation-circle' : 'info-circle');
                ?>"></i>
                <span><?php echo htmlspecialchars($_GET['message']); ?></span>
            </div>
            <script>
                // Auto-hide message after 5 seconds
                setTimeout(() => {
                    const messageBox = document.querySelector('.message-box');
                    if (messageBox) {
                        messageBox.classList.add('hide'); // Add hide class for fade out
                        setTimeout(() => messageBox.remove(), 500); // Remove after transition
                    }
                }, 5000);
            </script>
        <?php endif; ?>

        <section class="account-section">
            <h2 class="section-title"><i class="fas fa-user"></i> Profile Information</h2>

            <?php if ($customer_details): ?>
                <div class="profile-grid">
                    <div class="profile-item">
                        <span class="profile-label">Full Name</span>
                        <span class="profile-value"><?php echo htmlspecialchars($customer_details['full_name']); ?></span>
                    </div>
                    <div class="profile-item">
                        <span class="profile-label">Mobile Number</span>
                        <span class="profile-value"><?php echo htmlspecialchars($customer_details['mobile_number']); ?></span>
                    </div>
                    <div class="profile-item">
                        <span class="profile-label">Email Address</span>
                        <span class="profile-value"><?php echo htmlspecialchars($customer_details['email']); ?></span>
                    </div>
                    <div class="profile-item">
                        <span class="profile-label">Member Since</span>
                        <span class="profile-value"><?php echo date("F j, Y", strtotime($customer_details['created_at'])); ?></span>
                    </div>
                </div>
            <?php else: ?>
                <p class="no-data-message"><i class="fas fa-info-circle"></i> Unable to load profile information. Please contact support if this persists.</p>
            <?php endif; ?>
        </section>

        <section class="account-section text-center">
            <h2 class="section-title" style="justify-content: center;"><i class="fas fa-box"></i> Your Orders</h2>
            <p style="margin-bottom: 20px; color: var(--gray);">View details of your past and current orders.</p>
            <a href="order_history.php" class="btn">
                <i class="fas fa-history"></i> View Order History
            </a>
        </section>

    </div>

    <script>
        // Prevent form resubmission on page refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>
<?php
// Make sure to close the connection only once, at the very end of the script
// after all database operations are complete.
if (isset($conn) && $conn) {
    $conn->close();
}
?>