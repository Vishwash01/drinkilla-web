<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/db_connection.php'; // Ensure this path is correct for your database connection

$cart_count = 0; // Initialize cart count

if (isset($_SESSION['customer_id'])) {
    // User is logged in: Fetch cart count (unique items) from the database
    $customer_id = $_SESSION['customer_id'];
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT product_id) AS total_unique_items FROM carts WHERE user_id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $customer_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $cart_count = $row['total_unique_items'] > 0 ? $row['total_unique_items'] : 0;
        $stmt->close();
    } else {
        error_log("Failed to prepare cart count query in productdash.php: " . $conn->error);
    }
} else {
    // User is a guest: Fetch cart count (unique items) from the session
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        $cart_count = count($_SESSION['cart']);
    }
}

// --- Category Logic ---
$categories = [];
$category_query = "SELECT category_id, category_name, category_icon_class FROM categories ORDER BY category_name ASC";
$category_result = $conn->query($category_query);

if ($category_result) {
    while ($row = $category_result->fetch_assoc()) {
        $categories[] = $row;
    }
} else {
    error_log("Failed to fetch categories: " . $conn->error);
}

// Get the selected category ID from the URL (if any)
$selected_category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : null;

// Build the SQL query for products, with category filtering
$sql = "SELECT p.product_id, p.name, p.category, p.description, p.price, p.alcohol_percentage, p.volume, p.image_url, p.is_bestseller, p.is_new 
        FROM products p";

if ($selected_category_id) {
    // Join with categories table to filter by category_id
    $sql .= " JOIN categories c ON p.category_id = c.category_id WHERE c.category_id = ?";
}
$sql .= " ORDER BY p.name ASC";


// Prepare and execute the product query
$stmt_products = $conn->prepare($sql);

if ($selected_category_id) {
    if ($stmt_products) {
        $stmt_products->bind_param("i", $selected_category_id);
        $stmt_products->execute();
        $product_result = $stmt_products->get_result();
        $stmt_products->close(); // Close statement
    } else {
        error_log("Failed to prepare product query with category filter: " . $conn->error);
        $product_result = false; // Indicate query failure
    }
} else {
    // If no category selected, just execute the query without binding
    if ($stmt_products) {
        $stmt_products->execute();
        $product_result = $stmt_products->get_result();
        $stmt_products->close(); // Close statement
    } else {
        error_log("Failed to prepare product query without category filter: " . $conn->error);
        $product_result = false; // Indicate query failure
    }
}

// End of PHP logic, HTML starts below
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DrinkDrop - Premium Liquor Delivery</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="CSS file/productdashboard.css">
</head>
<body>
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>DRINKILA</h2>
            <p>Premium Liquor Delivery</p>
        </div>

        <nav class="sidebar-nav">
            <a href="productdash.php" class="sidebar-nav-item <?php echo empty($selected_category_id) ? 'active' : ''; ?>">
                <i class="fas fa-home"></i>
                <span>Home</span>
            </a>
            <a href="#" class="sidebar-nav-item">
                <i class="fas fa-glass-whiskey"></i>
                <span>Categories</span>
            </a>
            <a href="order_history.php" class="sidebar-nav-item">
                <i class="fas fa-history"></i>
                <span>Orders</span>
            </a>
            <a href="my_account.php" class="sidebar-nav-item">
                <i class="fas fa-user"></i>
                <span>My Account</span>
            </a>
        </nav>

        <div class="sidebar-categories">
            <h3>CATEGORIES</h3>
            <?php if (!empty($categories)): ?>
                <?php foreach ($categories as $category): ?>
                    <a href="productdash.php?category_id=<?php echo htmlspecialchars($category['category_id']); ?>" 
                       class="sidebar-category-item <?php echo ($selected_category_id == $category['category_id']) ? 'active' : ''; ?>">
                        <i class="<?php echo htmlspecialchars($category['category_icon_class']); ?>"></i>
                        <span><?php echo htmlspecialchars($category['category_name']); ?></span>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No categories found.</p>
            <?php endif; ?>
        </div>
    </aside>

    <div class="main-content">
        <header class="main-header">
            <div class="location-time">
                <div><i class="fas fa-clock"></i> 13 minutes</div>
                <div><i class="fas fa-map-marker-alt"></i> Ringanwada, Vapi</div>
            </div>
            
            <div class="search-bar">
                <i class="fas fa-search"></i>
                <input type="text" placeholder='Search "whisky"'>
            </div>
        </header>

        <div class="categories">
            <?php if (!empty($categories)): ?>
                <?php foreach ($categories as $category): ?>
                    <a href="productdash.php?category_id=<?php echo htmlspecialchars($category['category_id']); ?>" 
                       class="category-item <?php echo ($selected_category_id == $category['category_id']) ? 'active' : ''; ?>">
                        <div class="category-icon"><i class="<?php echo htmlspecialchars($category['category_icon_class']); ?>"></i></div>
                        <span><?php echo htmlspecialchars($category['category_name']); ?></span>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No categories found.</p>
            <?php endif; ?>
        </div>

        <div class="welcome-banner">
            <h2>WELCOME TO DRINKILA</h2>
            <p>Order premium liquor & enjoy FREE delivery</p>
        </div>

        <div class="section-header">
            <h3>Premium Collection</h3>
            <a href="productdash.php">View all</a> </div>

        <div class="product-grid">
            <?php
            if ($product_result && $product_result->num_rows > 0) {
                while($row = $product_result->fetch_assoc()) {
            ?>
            <div class="product-card">
                <div class="product-image">
                    <?php if ($row['is_bestseller']): ?>
                    <span class="product-badge">Bestseller</span>
                    <?php elseif ($row['is_new']): ?>
                    <span class="product-badge">New</span>
                    <?php endif; ?>
                    <img src="<?php echo htmlspecialchars($row['image_url']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                </div>
                <div class="product-info">
                    <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                    <div class="product-meta">
                        <span><?php echo htmlspecialchars($row['volume']); ?></span>
                        <span><?php echo htmlspecialchars($row['alcohol_percentage']); ?>% ABV</span>
                    </div>
                    <div class="product-price">₹<?php echo number_format($row['price'], 2); ?></div>
                    <div class="product-actions">
                        <form action="add_to_cart.php" method="POST">
                            <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($row['product_id']); ?>">
                            <button type="submit" class="add-to-cart-btn">
                                <i class="fas fa-shopping-cart"></i> ADD
                            </button>
                        </form>
                        <button class="wishlist-btn">
                            <i class="far fa-heart"></i>
                        </button>
                    </div>
                </div>
            </div>
            <?php
                }
            } else {
                echo "<p style='text-align: center; grid-column: 1 / -1; color: var(--gray); padding: 40px;'>No products found" . ($selected_category_id ? " for this category." : ".") . "</p>";
            }
            ?>
        </div>

        <?php if (isset($_GET['message'])): ?>
            <div class="message-container <?php echo isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'info'; ?>">
                <?php echo htmlspecialchars($_GET['message']); ?>
            </div>
        <?php endif; ?>

        <a href="cart.php" class="cart-btn">
            <i class="fas fa-shopping-cart"></i>
            <?php if ($cart_count > 0): ?>
            <span class="cart-count"><?php echo $cart_count; ?></span>
            <?php endif; ?>
        </a>

        <nav class="bottom-nav">
            <a href="productdash.php" class="nav-item <?php echo empty($selected_category_id) ? 'active' : ''; ?>">
                <i class="fas fa-home"></i>
                <span>Home</span>
            </a>
            <a href="#" class="nav-item">
                <i class="fas fa-glass-whiskey"></i>
                <span>Categories</span>
            </a>
            <a href="order_history.php" class="nav-item">
                <i class="fas fa-history"></i>
                <span>Orders</span>
            </a>
            <a href="my_account.php" class="nav-item">
                <i class="fas fa-user"></i>
                <span>Account</span>
            </a>
        </nav>
    </div>

    <script src="productdash1.js"></script>
</body>
</html>
<?php
// Close the database connection ONLY after all database operations are done
if (isset($conn)) {
    $conn->close();
}
?>