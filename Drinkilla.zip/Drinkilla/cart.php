<?php
// cart.php
session_start(); // Start the session to access $_SESSION['cart'] and $_SESSION['customer_id']

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/db_connection.php'; // Path to your database connection

$message = ''; // Initialize message variable for display
$type = 'info'; // Initialize message type

// --- Handle Cart Actions (Update Quantity, Remove Item) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = isset($_POST['product_id']) ? filter_var($_POST['product_id'], FILTER_VALIDATE_INT) : 0;
    $quantity = isset($_POST['quantity']) ? filter_var($_POST['quantity'], FILTER_VALIDATE_INT) : null; // Can be 0 for remove

    if ($product_id > 0) {
        if (isset($_SESSION['customer_id'])) {
            // LOGGED-IN USER: Update/Remove from Database
            $customer_id = $_SESSION['customer_id'];

            if (isset($_POST['update_quantity'])) {
                if ($quantity !== null && $quantity >= 0) {
                    if ($quantity > 0) {
                        // Check if item already exists in DB cart for this user
                        $stmt_check = $conn->prepare("SELECT quantity FROM carts WHERE user_id = ? AND product_id = ?");
                        if ($stmt_check) {
                            $stmt_check->bind_param("ii", $customer_id, $product_id);
                            $stmt_check->execute();
                            $result_check = $stmt_check->get_result();

                            if ($result_check->num_rows > 0) {
                                // Item exists, update quantity
                                $stmt = $conn->prepare("UPDATE carts SET quantity = ? WHERE user_id = ? AND product_id = ?");
                                if ($stmt) {
                                    $stmt->bind_param("iii", $quantity, $customer_id, $product_id);
                                    if ($stmt->execute()) {
                                        $message = "Quantity updated in your database cart!";
                                        $type = "success";
                                    } else {
                                        $message = "Failed to update quantity in database: " . $stmt->error;
                                        $type = "error";
                                    }
                                    $stmt->close();
                                } else {
                                    $message = "DB prepare error for update: " . $conn->error;
                                    $type = "error";
                                }
                            } else {
                                // Item does not exist, insert it (this could happen if session cart had it but DB didn't)
                                $stmt = $conn->prepare("INSERT INTO carts (user_id, product_id, quantity) VALUES (?, ?, ?)");
                                if ($stmt) {
                                    $stmt->bind_param("iii", $customer_id, $product_id, $quantity);
                                    if ($stmt->execute()) {
                                        $message = "Item added to your database cart!";
                                        $type = "success";
                                    } else {
                                        $message = "Failed to add item to database: " . $stmt->error;
                                        $type = "error";
                                    }
                                    $stmt->close();
                                } else {
                                    $message = "DB prepare error for insert: " . $conn->error;
                                    $type = "error";
                                }
                            }
                            $stmt_check->close();
                        } else {
                            $message = "DB prepare error for check: " . $conn->error;
                            $type = "error";
                        }
                    } else {
                        // Quantity is 0, remove from DB
                        $stmt = $conn->prepare("DELETE FROM carts WHERE user_id = ? AND product_id = ?");
                        if ($stmt) {
                            $stmt->bind_param("ii", $customer_id, $product_id);
                            if ($stmt->execute()) {
                                $message = "Item removed from your database cart.";
                                $type = "success";
                            } else {
                                $message = "Failed to remove item from database: " . $stmt->error;
                                $type = "error";
                            }
                            $stmt->close();
                        } else {
                            $message = "DB prepare error for delete: " . $conn->error;
                            $type = "error";
                        }
                    }
                } else {
                    $message = "Invalid quantity provided.";
                    $type = "error";
                }
            } elseif (isset($_POST['remove_item'])) {
                // Explicitly remove from DB
                $stmt = $conn->prepare("DELETE FROM carts WHERE user_id = ? AND product_id = ?");
                if ($stmt) {
                    $stmt->bind_param("ii", $customer_id, $product_id);
                    if ($stmt->execute()) {
                        $message = "Item removed from your database cart.";
                        $type = "success";
                    } else {
                        $message = "Failed to remove item from database: " . $stmt->error;
                        $type = "error";
                    }
                    $stmt->close();
                } else {
                    $message = "DB prepare error for delete: " . $conn->error;
                    $type = "error";
                }
            }
        } else {
            // GUEST USER: Update/Remove from Session
            if (isset($_POST['update_quantity']) && $quantity !== null && $quantity >= 0) {
                if ($quantity > 0) {
                    if (isset($_SESSION['cart'][$product_id])) {
                           $_SESSION['cart'][$product_id]['quantity'] = $quantity;
                           $message = "Quantity updated in session cart!";
                           $type = "success";
                    } else {
                           // This scenario means the product_id somehow wasn't in session cart, but update was attempted
                           $message = "Item not found in session cart to update quantity.";
                           $type = "error";
                    }
                } else {
                    unset($_SESSION['cart'][$product_id]);
                    $message = "Item removed from session cart.";
                    $type = "success";
                }
            } elseif (isset($_POST['remove_item'])) {
                if (isset($_SESSION['cart'][$product_id])) {
                    unset($_SESSION['cart'][$product_id]);
                    $message = "Item removed from session cart.";
                    $type = "success";
                } else {
                    $message = "Item not found in session cart.";
                    $type = "error";
                }
            }
        }
    } else {
        $message = "Invalid product ID.";
        $type = "error";
    }

    // Redirect to clear POST data and show message
    header("Location: cart.php?message=" . urlencode($message) . "&type=" . urlencode($type));
    exit();
}

// --- Fetch Cart Items for Display ---
$cart_items_for_display = []; // This array will hold the final items to display in your UI
$total_cart_price = 0;

if (isset($_SESSION['customer_id'])) {
    // LOGGED-IN USER: Fetch from Database
    $customer_id = $_SESSION['customer_id'];
    $stmt = $conn->prepare("
        SELECT
            c.product_id,
            c.quantity,
            p.name,
            p.price,
            p.image_url,
            p.volume,
            p.alcohol_percentage
        FROM
            carts c
        JOIN
            products p ON c.product_id = p.product_id
        WHERE
            c.user_id = ?
    ");
    if ($stmt === false) {
        error_log("Cart display DB prepare error: " . $conn->error);
        $message = "Error loading your cart from the database. Please try again.";
        $type = "error";
    } else {
        $stmt->bind_param("i", $customer_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Populate the display array with data directly from DB
                $cart_items_for_display[$row['product_id']] = $row;
                $total_cart_price += ($row['quantity'] * $row['price']);
            }
        }
        $stmt->close();
    }
} else {
    // GUEST USER: Fetch from Session
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        $product_ids_in_session_cart = array_keys($_SESSION['cart']);

        if (!empty($product_ids_in_session_cart)) {
            // Prepare placeholders for the IN clause
            $placeholders = implode(',', array_fill(0, count($product_ids_in_session_cart), '?'));
            // Determine parameter types (all integers 'i')
            $types = str_repeat('i', count($product_ids_in_session_cart));

            $stmt = $conn->prepare("SELECT product_id, name, price, image_url, volume, alcohol_percentage FROM products WHERE product_id IN ($placeholders)");
            if ($stmt === false) {
                error_log("Session cart display DB prepare error: " . $conn->error);
                $message = "Error loading session cart products. Please try again.";
                $type = "error";
            } else {
                // Bind parameters dynamically
                $stmt->bind_param($types, ...$product_ids_in_session_cart);
                $stmt->execute();
                $result = $stmt->get_result();

                $session_products_details_from_db = [];
                while ($row = $result->fetch_assoc()) {
                    $session_products_details_from_db[$row['product_id']] = $row;
                }
                $stmt->close();

                // Combine fetched details from DB with quantities stored in session
                foreach ($_SESSION['cart'] as $product_id => $item_data_from_session) {
                    if (isset($session_products_details_from_db[$product_id])) {
                        $product_details = $session_products_details_from_db[$product_id];
                        // Crucially, use the quantity from the session, not from the products table
                        $product_details['quantity'] = $item_data_from_session['quantity'];
                        $cart_items_for_display[$product_id] = $product_details;
                        $total_cart_price += ($product_details['quantity'] * $product_details['price']);
                    }
                }
            }
        }
    }
}

// THIS IS THE CRUCIAL ADDITION:
// After fetching and preparing $cart_items_for_display, ensure $_SESSION['cart'] is updated with this unified data.
// This makes sure $_SESSION['cart'] always reflects the *actual* cart content, whether from DB or previous session.
// This is critical for checkout.php which relies solely on $_SESSION['cart'].
$_SESSION['cart'] = $cart_items_for_display;

$conn->close(); // Close connection after all DB operations are done

// If there's a message from a GET parameter (after redirection from a POST), override any existing message
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
    $type = isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'info';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Shopping Cart - Drinkilla</title>
    <link rel="stylesheet" href="CSS File/your-styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Your original CSS provided earlier */
        :root {
            --primary: #FF7E33;
            --secondary: #1A1A1A;
            --light: #2D2D2D;
            --dark: #FFFFFF;
            --gray: #AAAAAA;
            --card-bg: #2D2D2D;
            --success: #4CAF50;
            --error: #F44336;
            --border-radius: 12px;
            --border-radius-sm: 8px;
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.3);
            --shadow-md: 0 4px 12px rgba(0,0,0,0.4);
            --transition: all 0.3s ease;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--secondary);
            color: var(--dark);
            margin: 0;
            padding: 0;
            padding-bottom: 70px; /* Space for bottom nav */
        }

        .header {
            background: var(--secondary);
            padding: 15px;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: var(--shadow-sm);
            border-bottom: 1px solid var(--light);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            color: var(--primary);
            font-size: 1.5em;
            margin: 0;
        }

        .back-btn {
            color: var(--primary);
            text-decoration: none;
            font-size: 0.9em;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .cart-container {
            max-width: 900px;
            margin: 20px auto;
            padding: 15px;
        }

        .message-container {
            padding: 15px;
            margin: 15px;
            border-radius: var(--border-radius-sm);
            text-align: center;
            font-weight: 500;
        }

        .message-container.success {
            background-color: rgba(76, 175, 80, 0.2);
            color: var(--success);
        }

        .message-container.error {
            background-color: rgba(244, 67, 54, 0.2);
            color: var(--error);
        }

        .cart-item {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 15px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 15px;
            border: 1px solid var(--light);
        }

        .cart-item-image {
            width: 80px;
            height: 80px;
            background: var(--light);
            border-radius: var(--border-radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
        }

        .cart-item-image img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .cart-item-details {
            flex: 1;
        }

        .cart-item-details h3 {
            font-size: 1em;
            margin-bottom: 5px;
            color: var(--dark);
        }

        .cart-item-details p {
            font-size: 0.8em;
            color: var(--gray);
            margin-bottom: 5px;
        }

        .item-price {
            font-size: 1em;
            font-weight: 600;
            color: var(--primary);
            min-width: 80px;
            text-align: right;
        }

        .item-quantity {
            display: flex;
            align-items: center;
            margin: 10px 0;
        }

        .item-quantity input {
            width: 50px;
            padding: 8px;
            text-align: center;
            background: var(--light);
            border: 1px solid #444;
            border-radius: var(--border-radius-sm);
            color: var(--dark);
            margin: 0 5px;
        }

        .quantity-btn {
            background: var(--primary);
            color: var(--dark);
            border: none;
            width: 30px;
            height: 30px;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            font-weight: bold;
        }

        .remove-btn {
            background: transparent;
            color: var(--gray);
            border: 1px solid var(--gray);
            padding: 5px 10px;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            font-size: 0.8em;
        }

        .cart-summary {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-top: 20px;
            border: 1px solid var(--light);
        }

        .cart-summary h3 {
            font-size: 1.2em;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px dashed #444;
        }

        .summary-row.total {
            font-weight: 600;
            font-size: 1.1em;
            border-bottom: none;
            padding-top: 10px;
        }

        .cart-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            gap: 15px;
        }

        .continue-shopping {
            background: var(--light);
            color: var(--dark);
            padding: 12px;
            border-radius: var(--border-radius);
            text-decoration: none;
            text-align: center;
            flex: 1;
            border: 1px solid #444;
        }

        .checkout-btn {
            background: var(--primary);
            color: var(--dark);
            padding: 12px;
            border-radius: var(--border-radius);
            text-decoration: none;
            text-align: center;
            flex: 1;
            font-weight: 500;
        }

        .empty-cart {
            text-align: center;
            padding: 40px 0;
            color: var(--gray);
        }

        .empty-cart i {
            font-size: 2.5em;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .empty-cart a {
            color: var(--primary);
            text-decoration: none;
        }

        /* Bottom Navigation - Mobile Only */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--secondary);
            display: none; /* Hidden by default, shown on mobile */
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.3);
            z-index: 100;
            border-top: 1px solid var(--light);
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            color: var(--gray);
            text-decoration: none;
            font-size: 0.8em;
            flex: 1; /* Distribute items evenly */
        }

        .nav-item i {
            font-size: 1.2em;
            margin-bottom: 3px;
        }

        .nav-item.active {
            color: var(--primary); /* Highlight active item */
        }

        @media (max-width: 768px) {
            .cart-item {
                flex-direction: column;
                align-items: flex-start;
            }

            .item-price {
                text-align: left;
                margin-top: 10px;
                width: 100%; /* Take full width on mobile */
            }

            .cart-actions {
                flex-direction: column;
            }

            .bottom-nav {
                display: flex; /* Show bottom nav on mobile */
            }

            .header {
                padding: 10px 15px; /* Adjust header padding for mobile */
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Your Shopping Cart</h1>
        <div class="cart-icon">
            <a href="productdash.php" class="back-btn"><i class="fas fa-arrow-left"></i> Continue Shopping</a>
        </div>
    </div>

    <div class="cart-container">
        <?php
        // Display messages from cart actions or errors during fetching
        if (!empty($message)) {
            echo "<div class='message-container {$type}'>{$message}</div>";
        }
        ?>

        <?php if (!empty($cart_items_for_display)): // Loop through the unified display array ?>
            <?php foreach ($cart_items_for_display as $productId => $item): ?>
                <div class="cart-item">
                    <div class="cart-item-image">
                        <img src="<?php echo htmlspecialchars($item['image_url'] ?? 'https://placehold.co/80x80/2D2D2D/AAAAAA?text=No+Image'); ?>" alt="<?php echo htmlspecialchars($item['name'] ?? 'Product'); ?>">
                    </div>
                    <div class="cart-item-details">
                        <h3><?php echo htmlspecialchars($item['name'] ?? 'Unknown Product'); ?></h3>
                        <p>Price: ₹<?php echo number_format($item['price'] ?? 0, 2); ?></p>
                        <p>• <?php echo htmlspecialchars($item['volume'] ?? 'N/A'); ?></p>
                        <p><?php echo htmlspecialchars($item['alcohol_percentage'] ?? 'N/A'); ?>% ABV</p>
                    </div>

                    <div class="item-quantity">
                        <form action="cart.php" method="POST" style="display:flex; align-items:center;">
                            <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($productId); ?>">
                            <input type="number" name="quantity" value="<?php echo htmlspecialchars($item['quantity'] ?? 1); ?>" min="0" onchange="this.form.submit()">
                            <button type="submit" name="update_quantity" class="quantity-btn" style="display:none;">Update</button>
                        </form>
                    </div>
                    <div class="item-price">
                        ₹<?php echo number_format(($item['price'] ?? 0) * ($item['quantity'] ?? 0), 2); ?>
                    </div>
                    <form action="cart.php" method="POST" style="display:inline;">
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($productId); ?>">
                        <button type="submit" name="remove_item" class="remove-btn">Remove</button>
                    </form>
                </div>
            <?php endforeach; ?>

            <div class="cart-summary">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span>₹<?php echo number_format($total_cart_price, 2); ?></span>
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span>₹<?php echo number_format($total_cart_price, 2); ?></span>
                </div>
            </div>

            <div class="cart-actions">
                <a href="productdash.php" class="continue-shopping">Continue Shopping</a>
                <a href="checkout.php" class="checkout-btn">Proceed to Checkout</a>
            </div>

        <?php else: ?>
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <p>Your cart is empty.</p>
                <p><a href="productdash.php">Start shopping!</a></p>
            </div>
        <?php endif; ?>
    </div>
    <div class="bottom-nav">
        <a href="productdash.php" class="nav-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="#" class="nav-item active">
            <i class="fas fa-shopping-cart"></i>
            <span>Cart</span>
        </a>
        <a href="profile.php" class="nav-item">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
        </div>
</body>
</html>