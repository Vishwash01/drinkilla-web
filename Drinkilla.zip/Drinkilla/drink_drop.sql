-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2025 at 09:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drink_drop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`, `email`, `full_name`, `created_at`) VALUES
(2, 'CTO', '$2y$10$A32GOFq5d.toApJH8wrB.OBAJe1h1Eq8elqzPy72rzDu6zbC13eii', 'vishwashofficial@gmail.com', 'Administrator', '2025-07-26 18:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `product_id`, `quantity`, `added_at`) VALUES
(25, 26, 24, 1, '2025-07-31 16:00:15');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_icon_class` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `category_icon_class`, `created_at`, `updated_at`) VALUES
(1, 'Whiskey', 'fas fa-whiskey-glass', '2025-07-30 14:29:49', '2025-07-30 14:29:49'),
(2, 'Vodka', 'fas fa-glass-water', '2025-07-30 14:29:49', '2025-07-30 14:29:49'),
(3, 'Gin', 'fas fa-martini-glass', '2025-07-30 14:29:49', '2025-07-30 14:29:49'),
(4, 'Rum', 'fas fa-rum', '2025-07-30 14:29:49', '2025-07-30 14:29:49'),
(5, 'Tequila', 'fas fa-cactus', '2025-07-30 14:29:49', '2025-07-30 14:29:49'),
(6, 'Brandy', 'fas fa-wine-glass', '2025-07-30 14:29:49', '2025-07-30 14:29:49'),
(7, 'Fortified Wines', 'fas fa-wine-bottle', '2025-07-30 14:29:49', '2025-07-30 14:29:49'),
(8, 'Liqueurs', 'fas fa-cocktail', '2025-07-30 14:29:49', '2025-07-30 14:29:49'),
(9, 'Beer', 'fas fa-beer-mug-empty', '2025-07-30 14:29:49', '2025-07-30 14:29:49'),
(10, 'Wine', 'fas fa-wine-glass', '2025-07-30 14:29:49', '2025-07-30 14:29:49');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `mobile_number` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `full_name`, `mobile_number`, `email`, `password`, `created_at`) VALUES
(21, 'vishwash', '9879275954', 'vishwashofficial1@gmail.com', '$2y$10$mI0bIRgBlE2.tqumCGBG5OtDB3hqp1BbXLHBZZnQ.ogXRMOsiDK8q', '2025-07-23 14:41:58'),
(24, 'Nitish Yadav', '7016096955', 'nitishofficial1@gmail.com', '$2y$10$jTGSLy1hTNTicwICr.QZVOZuu4eJZgn6V1.PuwgZCPBqIz4hpt0Xy', '2025-07-24 06:03:11'),
(26, 'Sanket', '9839240071', 'sanket@gmail.com', '$2y$10$LdDL5olnjsfht8iFvgLxr.C5nP5qMk4K2Kl5J1CzHvPeKOXny03yW', '2025-07-31 15:54:26');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `shipping_address` text NOT NULL,
  `shipping_city` varchar(100) NOT NULL,
  `shipping_state` varchar(100) NOT NULL,
  `shipping_zip` varchar(20) NOT NULL,
  `status` varchar(50) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `order_date`, `total_amount`, `customer_name`, `customer_email`, `customer_phone`, `shipping_address`, `shipping_city`, `shipping_state`, `shipping_zip`, `status`) VALUES
(4, NULL, '2025-07-30 20:58:43', 950.00, 'Vishwash Upadhyay', 'vishwashofficial1@gmail.com', '9839240071', 'kachigam', 'daman', 'daman', '396210', 'Pending'),
(5, NULL, '2025-07-30 21:17:11', 950.00, 'Vishwash Upadhyay', 'vishwashofficial1@gmail.com', '9839240071', 'dhodiyawad', 'daman', 'daman', '396210', 'Pending'),
(6, NULL, '2025-07-30 21:20:48', 1200.00, 'Vishwash Upadhyay', 'vishwashofficial1@gmail.com', '9839240071', 'Kachigam Nani Koliwad Daman', 'Daman', 'Daman', '396210', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price_at_purchase` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price_at_purchase`) VALUES
(5, 4, 22, 1, 950.00),
(6, 5, 22, 1, 950.00),
(7, 6, 20, 1, 1200.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `alcohol_percentage` varchar(10) DEFAULT NULL,
  `volume` varchar(50) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `is_bestseller` tinyint(1) DEFAULT 0,
  `is_new` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `category`, `description`, `price`, `category_id`, `alcohol_percentage`, `volume`, `image_url`, `is_bestseller`, `is_new`, `created_at`, `updated_at`) VALUES
(18, 'Jhon Martin', 'Whisky', 'sasta bhi acha bhi', 1100.00, NULL, '20', '100ml', 'images/products/product2.png', 1, 0, '2025-07-30 14:27:12', '2025-07-30 14:27:12'),
(19, 'Johnnie Walker Red Label', 'Whiskey', 'A classic Scotch whisky, perfect for mixing.', 1500.00, 1, '40%', '750ml', 'images/products/product2.png', 1, 0, '2025-07-30 14:43:00', '2025-07-30 14:43:00'),
(20, 'Absolut Vodka', 'Vodka', 'A pure and smooth Swedish vodka.', 1200.00, 2, '40%', '750ml', 'images/products/product.png', 1, 0, '2025-07-30 14:43:00', '2025-07-30 14:43:00'),
(21, 'Bombay Sapphire Gin', 'Gin', 'A vibrant and aromatic gin.', 1800.00, 3, '47%', '750ml', 'images/products/product2.png', 0, 1, '2025-07-30 14:43:00', '2025-07-30 14:43:00'),
(22, 'Bacardi Carta Blanca Rum', 'Rum', 'A light and aromatic white rum.', 950.00, 4, '40%', '750ml', 'images/products/product2.png', 0, 0, '2025-07-30 14:43:00', '2025-07-30 14:43:00'),
(23, 'Don Julio Blanco Tequila', 'Tequila', 'A crisp and clear tequila with sweet agave notes.', 3000.00, 5, '38%', '750ml', 'images/products/product2.png', 1, 0, '2025-07-30 14:43:00', '2025-07-30 14:43:00'),
(24, 'Hennessy VS Cognac', 'Brandy', 'A bold and fragrant cognac.', 4500.00, 6, '40%', '700ml', 'images/products/product.png', 0, 0, '2025-07-30 14:43:00', '2025-07-30 14:43:00'),
(25, 'Jacob\'s Creek Shiraz', 'Wine', 'A medium-bodied red wine with rich fruit flavors.', 800.00, 10, '13.5%', '750ml', 'images/products/product.png', 0, 1, '2025-07-30 14:43:00', '2025-07-30 14:43:00'),
(26, 'Kingfisher Strong Beer', 'Beer', 'A popular strong lager from India.', 150.00, 9, '8%', '650ml', 'images/products/product2.png', 1, 0, '2025-07-30 14:43:00', '2025-07-30 14:43:00'),
(27, 'Baileys Irish Cream', 'Liqueurs', 'A smooth blend of Irish whiskey and cream.', 1600.00, 8, '17%', '700ml', 'images/products/product2.png', 0, 0, '2025-07-30 14:43:00', '2025-07-30 14:43:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mobile_number` (`mobile_number`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `fk_products_category_link` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `carts_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_category_link` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_products_category_new` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
