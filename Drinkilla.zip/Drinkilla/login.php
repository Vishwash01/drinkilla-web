<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>DrinkDrop- Login</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="CSS File/login.css"/>
</head>
<body>
    <div class="container">
        <div class="logo">DrinkDrop</div>
        <div class="title">Sign in to continue</div>

    <?php
        // PHP code to display messages from the server after redirection (from signup_process.php)
        if (isset($_GET['message'])) {
            $message = htmlspecialchars($_GET['message']);
            $type = isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'info';
            // IMPORTANT: Give this message element a unique ID for JavaScript to target
            echo "<p id='auto-hide-redirect-message' class='form-message {$type}'>{$message}</p>";
        }
        ?>

        <div class="phone-section">
            <div class="input-wrap">
                <i class="fas fa-phone"></i>
                <span>+91</span>
                <input type="tel" id="phone" placeholder="Enter mobile number" pattern="[0-9]{10}" maxlength="10" required />
            </div>
            <button class="btn" id="continue-btn">Continue</button>
        </div>

        <div class="otp-section" id="otp-section">
            <input type="text" class="otp-input" id="otp" maxlength="6" placeholder="______" />
            <button class="btn" id="verify-btn">Verify OTP</button>
            <div class="resend">
                Didn't get the OTP? 
                <button id="resend-btn" disabled>Resend in <span id="timer">30</span>s</button>
            </div>
        </div>

        <div class="social">
            <button><i class="fab fa-google"></i> Continue with Google</button>
        </div>

        <div class="note">By continuing, you agree to our Terms & Privacy Policy.</div>
    </div>

    <script src="JS File/login.js"></script>
        
        <script>
     document.addEventListener('DOMContentLoaded', function() {
            const redirectMessageElement = document.getElementById('auto-hide-redirect-message');
            if (redirectMessageElement) {
                // Fade out the message after 4 seconds, then remove it
                setTimeout(function() {
                    redirectMessageElement.style.opacity = '0'; // Start fade out
                    setTimeout(function() {
                        redirectMessageElement.remove(); // Remove after fade
                    }, 500); // Duration of the fade transition in CSS
                }, 2000); // Message visible for 4 seconds
            }
        });
        </script>
</body>
</html>