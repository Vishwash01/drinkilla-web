<?php
session_start();
require_once 'includes/db_connection.php'; // Or just for display, don't need it if only showing GET data

$order_id = $_GET['order_id'] ?? 'N/A';
$message = $_GET['message'] ?? 'Your order has been placed.';
$type = $_GET['type'] ?? 'success';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
         body { background: #1A1A1A; color: #FFFFFF; font-family: 'Poppins', sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .confirmation-container { background: #2D2D2D; padding: 40px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.5); text-align: center; max-width: 600px; width: 90%; }
        .confirmation-container h1 { color: #4CAF50; font-size: 2.5em; margin-bottom: 20px; }
        .confirmation-container p { font-size: 1.1em; margin-bottom: 15px; color: #AAAAAA; }
        .confirmation-container .order-id { font-size: 1.3em; font-weight: bold; color: #FF7E33; margin-top: 10px; }
        .confirmation-container .button-group { margin-top: 30px; display: flex; justify-content: center; gap: 15px; }
        .confirmation-container .btn { background: #FF7E33; color: #FFFFFF; padding: 12px 25px; border: none; border-radius: 8px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; }
        .confirmation-container .btn:hover { background: #e66a2a; transform: translateY(-2px); }
    </style>
</head>
<body>
    <div class="confirmation-container">
        <h1><i class="fas fa-check-circle"></i> Order Confirmed!</h1>
        <p><?php echo htmlspecialchars($message); ?></p>
        <p class="order-id">Your Order ID: <?php echo htmlspecialchars($order_id); ?></p>
        <div class="button-group">
            <a href="productdash.php" class="btn">Continue Shopping</a>
            <?php if (isset($_SESSION['customer_id'])): ?>
                <a href="order_history.php" class="btn">View My Orders</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>