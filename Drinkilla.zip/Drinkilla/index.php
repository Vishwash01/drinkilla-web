<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BoozeExpress - Premium Liquor Delivery</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="CSS file/index.css">
</head>
<body>
    <div id="beer-3d"></div>

    <nav class="navbar">
        <a href="#" class="logo">BoozeExpress</a>
        
        <div class="nav-links">
            <a href="#">Home</a>
            <a href="#">Shop</a>
            <a href="#">Categories</a>
            <a href="#">Deals</a>
            <a href="#">About</a>
        </div>
        
        <div class="nav-actions">
            <div class="auth-buttons">
                <a href="#" class="auth-btn login-btn">Login</a>
                <a href="#" class="auth-btn signup-btn">Sign Up</a>
            </div>
            
            <div class="profile-btn" id="profileBtn">
                <i class="fas fa-user"></i>
                <div class="profile-dropdown" id="profileDropdown">
                    <div class="profile-header">
                        <div class="profile-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <div>
                            <div class="profile-name">John Doe</div>
                            <div class="profile-email">john@example.com</div>
                        </div>
                    </div>
                    <ul class="profile-menu">
                        <li><a href="#"><i class="fas fa-user-circle"></i> My Profile</a></li>
                        <li><a href="#"><i class="fas fa-shopping-bag"></i> Orders</a></li>
                        <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
                        <li><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
            
            <a href="#" class="cart-icon">
                <i class="fas fa-shopping-cart"></i>
                <span class="cart-count">3</span>
            </a>
            
            <div class="hamburger">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>

    <section class="hero">
        <div class="hero-content">
            <h1>Premium Liquor Delivered to Your Door</h1>
            <p>Discover the finest selection of spirits, wines, and beers with fast delivery and exceptional service.</p>
            
            <div class="search-bar">
                <i class="fas fa-search search-icon"></i>
                <input type="text" placeholder="Search whiskey, vodka, beer...">
            </div>
        </div>
    </section>

    <section class="categories-section">
        <div class="section-title">
            <h2>Categories</h2>
            <p>Browse our wide selection</p>
        </div>
        
        <div class="categories">
            <div class="category">
                <div class="category-icon">
                    <i class="fas fa-beer"></i>
                </div>
                <span class="category-name">Beer</span>
            </div>
            <div class="category">
                <div class="category-icon">
                    <i class="fas fa-wine-glass-alt"></i>
                </div>
                <span class="category-name">Wine</span>
            </div>
            <div class="category">
                <div class="category-icon">
                    <i class="fas fa-cocktail"></i>
                </div>
                <span class="category-name">Vodka</span>
            </div>
            <div class="category">
                <div class="category-icon">
                    <i class="fas fa-wine-bottle"></i>
                </div>
                <span class="category-name">Rum</span>
            </div>
            <div class="category">
                <div class="category-icon">
                    <i class="fas fa-whiskey-glass"></i>
                </div>
                <span class="category-name">Whiskey</span>
            </div>
            <div class="category">
                <div class="category-icon">
                    <i class="fas fa-glass-martini-alt"></i>
                </div>
                <span class="category-name">Gin</span>
            </div>
        </div>
    </section>

    <section class="products-section">
        <div class="products-header">
            <div class="section-title">
                <h2>Popular Now</h2>
                <p>Our best selling products</p>
            </div>
        </div>
        
        <div class="products-grid">
            <div class="product-card">
                <div class="product-badge">-15%</div>
                <div class="product-image-container">
                    <img src="bee1.webp" class="product-image" alt="Jack Daniel's">
                </div>
                <div class="product-info">
                    <h3 class="product-name">Jack Daniel's</h3>
                    <p class="product-details">750ml • 40% ABV</p>
                    <div class="product-price">$22.80</div>
                    <div class="product-actions">
                        <button class="add-to-cart">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="product-card">
                <div class="product-image-container">
                    <img src="bee1.webp" class="product-image" alt="Absolut Vodka">
                </div>
                <div class="product-info">
                    <h3 class="product-name">Absolut Vodka</h3>
                    <p class="product-details">750ml • 40% ABV</p>
                    <div class="product-price">$18.99</div>
                    <div class="product-actions">
                        <button class="add-to-cart">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="product-card">
                <div class="product-badge">New</div>
                <div class="product-image-container">
                    <img src="bee2.jpeg" class="product-image" alt="Captain Morgan">
                </div>
                <div class="product-info">
                    <h3 class="product-name">Captain Morgan</h3>
                    <p class="product-details">750ml • 35% ABV</p>
                    <div class="product-price">$13.99</div>
                    <div class="product-actions">
                        <button class="add-to-cart">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="product-card">
                <div class="product-image-container">
                    <img src="bee2.jpeg" class="product-image" alt="Tanqueray Gin">
                </div>
                <div class="product-info">
                    <h3 class="product-name">Tanqueray Gin</h3>
                    <p class="product-details">750ml • 47.3% ABV</p>
                    <div class="product-price">$24.99</div>
                    <div class="product-actions">
                        <button class="add-to-cart">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="product-card">
                <div class="product-image-container">
                    <img src="champ.jpg" class="product-image" alt="Budweiser">
                </div>
                <div class="product-info">
                    <h3 class="product-name">Budweiser</h3>
                    <p class="product-details">330ml • 5% ABV</p>
                    <div class="product-price">$9.75</div>
                    <div class="product-actions">
                        <button class="add-to-cart">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="product-card">
                <div class="product-image-container">
                    <img src="champ.jpg" class="product-image" alt="Heineken">
                </div>
                <div class="product-info">
                    <h3 class="product-name">Heineken</h3>
                    <p class="product-details">330ml • 5% ABV</p>
                    <div class="product-price">$5.75</div>
                    <div class="product-actions">
                        <button class="add-to-cart">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="footer-logo">BoozeExpress</div>
        
        <div class="footer-links">
            <a href="#">Home</a>
            <a href="#">Shop</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms</a>
        </div>
        
        <div class="social-links">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-tiktok"></i></a>
        </div>
        
        <p class="copyright">© 2023 BoozeExpress. All rights reserved.</p>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js"></script>

    <script src="JS File/index.js"></script>
</body>
</html>