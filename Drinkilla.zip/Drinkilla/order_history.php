<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Path to your database connection file (assuming it's in includes/ relative to this file)
require_once 'includes/db_connection.php';

// Redirect if user is not logged in
if (!isset($_SESSION['customer_id'])) {
    header('Location: login.php?message=' . urlencode('Please log in to view your order history.') . '&type=info');
    exit();
}

$user_id = $_SESSION['customer_id'];
$orders = []; // Array to store all orders for the user

// Message variables for display
$display_message = '';
$display_type = '';

// Fetch orders for the logged-in user
$sql_orders = "SELECT order_id, total_amount, order_date, status FROM orders WHERE user_id = ? ORDER BY order_date DESC";
$stmt_orders = $conn->prepare($sql_orders);

if ($stmt_orders) {
    $stmt_orders->bind_param("i", $user_id);
    $stmt_orders->execute();
    $result_orders = $stmt_orders->get_result();

    if ($result_orders->num_rows > 0) {
        while ($order = $result_orders->fetch_assoc()) {
            $order_id = $order['order_id'];
            $order['items'] = []; // Initialize an array to store items for this order

            // Fetch items for the current order
            $sql_items = "SELECT oi.quantity, oi.price_at_purchase, p.name AS product_name
                          FROM order_items oi
                          JOIN products p ON oi.product_id = p.product_id
                          WHERE oi.order_id = ?";
            $stmt_items = $conn->prepare($sql_items);

            if ($stmt_items) {
                $stmt_items->bind_param("i", $order_id);
                $stmt_items->execute();
                $result_items = $stmt_items->get_result();

                while ($item = $result_items->fetch_assoc()) {
                    $order['items'][] = $item;
                }
                $stmt_items->close();
            } else {
                error_log("Failed to prepare statement for order items: " . $conn->error);
                $display_message = "Error fetching details for some orders. Please try again.";
                $display_type = "error";
            }
            $orders[] = $order; // Add the order (with its items) to the orders array
        }
    } else {
        $display_message = "You have no orders yet. Start exploring our products!";
        $display_type = "info";
    }
    $stmt_orders->close();
} else {
    error_log("Failed to prepare statement for user orders: " . $conn->error);
    $display_message = "Could not retrieve your order history. Please try again later.";
    $display_type = "error";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Order History</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="CSS File/customer_orders_styles.css">
</head>
<body>
    <div class="container">
        <header class="page-header">
            <h1><i class="fas fa-history"></i> My Order History</h1>
            <p>View all your past purchases with Drinkila.</p>
            <a href="productdash.php" class="back-to-shop-btn"><i class="fas fa-arrow-left"></i> Continue Shopping</a>
        </header>

        <?php
        // Display messages
        if (!empty($display_message)) {
            echo "<div class='message-container {$display_type} show'>";
            echo "  <i class='" . ($display_type == 'success' ? 'fas fa-check-circle' : ($display_type == 'error' ? 'fas fa-exclamation-circle' : 'fas fa-info-circle')) . "'></i>";
            echo "  <span>{$display_message}</span>";
            echo "</div>";
            // JavaScript to hide the message after a few seconds (optional for frontend)
            echo "<script>";
            echo "  setTimeout(() => {";
            echo "    const msgContainer = document.querySelector('.message-container');";
            echo "    if (msgContainer) {";
            echo "      msgContainer.classList.remove('show');"; // Trigger fade-out
            echo "      setTimeout(() => msgContainer.remove(), 500);"; // Remove from DOM after transition
            echo "    }";
            echo "  }, 5000);"; // Message disappears after 5 seconds
            echo "</script>";
        }
        ?>

        <div class="order-list">
            <?php if (!empty($orders)): ?>
                <?php foreach ($orders as $order): ?>
                    <div class="order-card">
                        <div class="order-summary-header">
                            <h2 class="order-id"><i class="fas fa-receipt"></i> Order #<?php echo htmlspecialchars($order['order_id']); ?></h2>
                            <span class="order-date">
                                <i class="far fa-calendar-alt"></i>
                                <?php echo date('F j, Y', strtotime($order['order_date'])); ?>
                            </span>
                        </div>
                        <div class="order-details-grid">
                            <div class="detail-item">
                                <p class="label">Total Amount:</p>
                                <p class="value total-amount">₹<?php echo number_format($order['total_amount'], 2); ?></p>
                            </div>
                            <div class="detail-item">
                                <p class="label">Status:</p>
                                <p class="value">
                                    <span class="order-status status-<?php echo strtolower(htmlspecialchars($order['status'])); ?>">
                                        <?php echo htmlspecialchars($order['status']); ?>
                                    </span>
                                </p>
                            </div>
                        </div>

                        <?php if (!empty($order['items'])): ?>
                            <div class="order-items-list">
                                <h3><i class="fas fa-boxes"></i> Items in this order:</h3>
                                <?php foreach ($order['items'] as $item): ?>
                                    <div class="order-item-detail">
                                        <span class="item-name"><?php echo htmlspecialchars($item['product_name']); ?> (x<?php echo htmlspecialchars($item['quantity']); ?>)</span>
                                        <span class="item-price">₹<?php echo number_format($item['price_at_purchase'] * $item['quantity'], 2); ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="order-items-list">
                                <p class="no-items-message"><i class="fas fa-exclamation-triangle"></i> No items found for this order. Please contact support if you believe this is an error.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <?php if (empty($display_message)): ?>
                    <div class="no-orders-message">
                        <p><i class="fas fa-frown"></i> You haven't placed any orders yet.</p>
                        <a href="productdash.php" class="start-shopping-btn"><i class="fas fa-shopping-cart"></i> Start Shopping Now</a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>