
<?php
session_start(); // THIS IS THE NEW LINE

// productdash.php
// Include your database connection file
require_once 'includes/db_connection.php';

// ... rest of your productdash.php code ...
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drinkila - Premium Liquor Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="CSS file/producdash.css">
    <style>
        :root {
    --primary: #1a1a2e;    /* Dark navy */
    --secondary: #d4af37;  /* Gold accent */
    --accent: #b11226;     /* Deep red */
    --light: #f8f8f8;
    --dark: #0d0d0d;
    --gray: #2a2a2a;
    --card-bg: #ffffff;
    --border-radius: 12px;
    --transition: all 0.3s ease;
    --header-height: 80px;
    --sidebar-width: 260px;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Montserrat', 'Arial', sans-serif;
}

body {
    margin: 0;
    background: var(--light);
    color: var(--dark);
    min-height: 100vh;
    line-height: 1.5;
}

/* Layout Structure */
.app-container {
    display: flex;
    min-height: 100vh;
}

/* Fixed Sidebar */
.sidebar {
    width: var(--sidebar-width);
    background: var(--dark);
    color: var(--light);
    height: 100vh;
    padding: 25px 20px;
    position: fixed;
    top: 0;
    left: 0;
    box-shadow: 5px 0 15px rgba(0,0,0,0.1);
    overflow-y: auto;
    z-index: 100;
    display: flex;
    flex-direction: column;
}

.sidebar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding-bottom: 15px;
    border-bottom: 2px solid rgba(212, 175, 55, 0.3);
}

.sidebar h2 {
    font-size: 24px;
    color: var(--secondary);
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
}

.sidebar h2 i {
    color: var(--accent);
}

.sidebar ul {
    list-style: none;
    padding: 0;
    flex-grow: 1;
}

.sidebar ul li {
    margin: 15px 0;
    padding: 12px 15px;
    border-radius: var(--border-radius);
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 500;
    transition: var(--transition);
    cursor: pointer; /* Added cursor for better UX */
}

.sidebar ul li i {
    width: 20px;
    color: var(--secondary);
}

.sidebar ul li:hover {
    background: rgba(212, 175, 55, 0.1);
    color: var(--secondary);
    transform: translateX(5px);
}

.sidebar ul li.active {
    background: var(--accent);
    color: white;
}

.sidebar ul li.active i {
    color: white;
}

/* Main Content Area */
.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    padding-top: var(--header-height);
    background: var(--light); /* Changed to light background for main content */
    min-height: 100vh;
}

/* Fixed Header */
.main-header {
    position: fixed;
    top: 0;
    left: var(--sidebar-width);
    right: 0;
    height: var(--header-height);
    background: var(--dark);
    padding: 0 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 99;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
}

.main-header h1 {
    font-size: 28px;
    color: var(--secondary);
    font-weight: 700;
    margin: 0;
}

.search-bar {
    display: flex;
    align-items: center;
    background: white;
    border-radius: var(--border-radius);
    padding: 10px 20px;
    width: 300px;
}

.search-bar input {
    border: none;
    outline: none;
    padding: 8px;
    width: 100%;
    font-size: 14px;
    color: var(--dark);
}

.search-bar i {
    color: var(--gray);
}

/* Profile Section */
.profile-section {
    position: relative;
}

.profile-button {
    background: var(--secondary);
    color: var(--dark);
    border: none;
    padding: 10px 15px;
    border-radius: var(--border-radius);
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    transition: var(--transition);
}

.profile-button:hover {
    background: #c9a227;
}

.profile-dropdown {
    position: absolute;
    top: calc(100% + 10px);
    right: 0;
    background: var(--dark);
    border-radius: var(--border-radius);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    min-width: 200px;
    z-index: 1000;
    opacity: 0;
    visibility: hidden;
    transform: translateY(-10px);
    transition: var(--transition);
}

.profile-dropdown.show {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

.profile-dropdown ul {
    list-style: none;
    padding: 10px 0;
}

.profile-dropdown ul li {
    padding: 12px 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: var(--light);
    transition: var(--transition);
    cursor: pointer; /* Added cursor for better UX */
}

.profile-dropdown ul li:hover {
    background: rgba(212, 175, 55, 0.1);
    color: var(--secondary);
}

.profile-dropdown ul li i {
    color: var(--secondary);
}

/* Main Content */
.main {
    padding: 30px 40px;
    max-width: 1440px;
    margin: 0 auto;
}

/* Product Grid */
.product-grid {
    display: grid;
    gap: 25px;
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
}

.product-card {
    background: var(--card-bg);
    border-radius: var(--border-radius);
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: var(--transition);
}

.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.product-image {
    width: 100%;
    height: 240px;
    background: white;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    position: relative;
}

.product-image img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
    transition: var(--transition);
}

.product-card:hover .product-image img {
    transform: scale(1.05);
}

.product-badge {
    position: absolute;
    top: 15px;
    left: 15px;
    background: var(--accent);
    color: white;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.product-info {
    padding: 20px;
}

.product-info h3 {
    font-size: 16px;
    margin-bottom: 12px;
    color: var(--primary);
    font-weight: 600;
}

.product-meta {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    font-size: 14px;
    color: var(--gray);
}

.product-price {
    font-size: 18px;
    font-weight: 700;
    color: var(--accent);
    margin-bottom: 20px;
}

.product-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
}

.add-to-cart-btn {
    background: var(--secondary);
    color: var(--dark);
    border: none;
    padding: 10px 20px;
    border-radius: var(--border-radius);
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.add-to-cart:hover {
    background: #c9a227;
    transform: translateY(-2px);
}

.wishlist-btn {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: var(--light);
    border: 1px solid #eee;
    cursor: pointer;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--gray); /* Added default color for wishlist icon */
}

.wishlist-btn:hover {
    color: var(--accent);
    border-color: var(--accent);
}

/* Mobile Profile Button */
.mobile-profile-button {
    display: none;
    width: 45px;
    height: 45px;
    border-radius: 50%;
    background: var(--accent);
    color: white;
    justify-content: center;
    align-items: center;
    font-size: 20px;
    cursor: pointer;
}


 /* Add these styles (or ensure they are in your CSS File/your-styles.css) */
        .message-container {
            text-align: center;
            padding: 15px;
            margin: 20px auto;
            border-radius: 8px;
            max-width: 600px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }
        .message-container.success {
            background-color: #4CAF50; /* Green */
            color: white;
        }
        .message-container.error {
            background-color: #f44336; /* Red */
            color: white;
        }
        .message-container.info {
            background-color: #2196F3; /* Blue */
            color: white;
        }
        
/* Responsive Adjustments */
@media (max-width: 1200px) {
    .product-grid {
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    }
}

@media (max-width: 992px) {
    :root {
        --sidebar-width: 220px;
    }
    
    .main {
        padding: 25px 30px;
    }
    
    .product-grid {
        gap: 20px;
    }
}

@media (max-width: 768px) {
    .app-container {
        flex-direction: column;
    }
    
    .sidebar {
        width: 100%;
        height: auto;
        position: relative;
        padding: 20px;
    }
    
    .main-content {
        margin-left: 0;
        padding-top: 0;
    }
    
    .main-header {
        position: relative;
        left: 0;
        flex-direction: column;
        height: auto;
        padding: 20px;
        gap: 15px;
    }
    
    .search-bar {
        width: 100%;
    }
    
    .profile-button {
        display: none;
    }
    
    .mobile-profile-button {
        display: flex;
    }
    
    .main {
        padding: 20px;
    }
    
    .sidebar ul {
        display: flex;
        overflow-x: auto;
        padding-bottom: 15px;
        gap: 10px;
        -webkit-overflow-scrolling: touch; /* For smoother scrolling on iOS */
    }
    
    .sidebar ul li {
        flex-shrink: 0;
        white-space: nowrap;
        margin: 0;
    }
}

@media (max-width: 576px) {
    .main {
        padding: 15px;
    }
    
    .product-grid {
        grid-template-columns: 1fr;
    }
    
    .product-image {
        height: 200px;
    }
}

@media (max-width: 480px) {
    .main-header {
        padding: 15px;
    }
    
    .product-image {
        height: 180px;
    }
}
    </style>
</head>
<body>
    <div class="app-container">
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-cocktail"></i> Drinkila</h2>
                <div class="mobile-profile-button" id="mobileProfileButton">
                    <i class="fas fa-user"></i>
                </div>
            </div>
            <ul>
                <li class="active"><i class="fas fa-whiskey-glass"></i> Whisky</li>
                <li><i class="fas fa-beer-mug-empty"></i> Beer</li>
                <li><i class="fas fa-wine-glass"></i> Wine</li>
                <li><i class="fas fa-glass-water"></i> Vodka</li>
                <li><i class="fas fa-rum"></i> Rum</li>
                <li><i class="fas fa-wine-bottle"></i> Brandy</li>
                <li><i class="fas fa-champagne-glasses"></i> Champagne</li>
                <li><i class="fas fa-martini-glass-citrus"></i> Cocktails</li>
            </ul>
        </div>

        <div class="main-content">
             <?php
        // Display messages from add_to_cart.php
        if (isset($_GET['message'])) {
            $message = htmlspecialchars($_GET['message']);
            $type = isset($_GET['type']) ? htmlspecialchars($_GET['type']) : 'info';
            echo "<div class='message-container {$type}'>{$message}</div>";
        }
        ?>
            <header class="main-header">
                <h1>Premium Liquor Collection</h1>
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search for drinks...">
                </div>
                <div class="profile-section">
                    <button class="profile-button" id="profileButton">
                        <i class="fas fa-user-circle"></i> My Account
                    </button>
                    <div class="profile-dropdown" id="profileDropdown">
                        <ul>
                            <li><i class="fas fa-user-edit"></i> Edit Profile</li>
                            <li><i class="fas fa-history"></i> Order History</li>
                            <li><i class="fas fa-shopping-bag" href="cart.php"></i> My Cart</li>
                            <li><i class="fas fa-cog"></i> Settings</li>
                            <li><i class="fas fa-sign-out-alt"></i> Logout</li>
                        </ul>
                    </div>
                </div>
            </header>

            <main class="main">
                <div class="product-grid">


                 <?php
            // Query to fetch all products from the database
            // You can add WHERE clauses here later to filter by category
            $sql = "SELECT id, name, category, description, price, alcohol_percentage, volume, image_url, is_bestseller, is_new 
                    FROM products 
                    ORDER BY name ASC"; // Order by name for now

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    ?>



                    <div class="product-card">
                        <div class="product-image">
                            <?php if ($row['is_bestseller']): ?>
                            <span class="product-badge">Bestseller</span>
                           
                            <?php elseif ($row['is_new']): ?>
                            <span class="product-badge">New</span>
                            
                            <?php endif; ?>
                           <img src="<?php echo htmlspecialchars($row['image_url']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                        </div>
                        <div class="product-info">
                            <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                            <div class="product-meta">
                                <span><?php echo htmlspecialchars($row['volume']); ?></span>
                                <span><?php echo htmlspecialchars($row['alcohol_percentage']); ?></span>
                            </div>
                            <div class="product-price"><?php echo number_format($row['price'], 2); ?></div>
                            <div class="product-actions">
                                 <form action="add_to_cart.php" method="POST" > 
                                    <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                <button type="submit" class="add-to-cart-btn"><i class="fas fa-shopping-cart"></i>
                ADD</button>
</form>
                                <button class="wishlist-btn">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                 <?php
                    } // <-- Closing brace for the WHILE loop
                } else {
                    echo "<p style='text-align: center; width: 100%; color: #aaa;'>No products found.</p>";
                }

                $conn->close(); // Close the database connection
                ?>
    <script >// Sidebar navigation active state
document.querySelectorAll('.sidebar ul li').forEach(item => {
    item.addEventListener('click', function() {
        document.querySelectorAll('.sidebar ul li').forEach(li => li.classList.remove('active'));
        this.classList.add('active');
    });
});

// Wishlist toggle functionality
document.querySelectorAll('.wishlist-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const icon = this.querySelector('i');
        // Toggle between 'far' (regular) and 'fas' (solid) heart icons
        if (icon.classList.contains('far')) {
            icon.classList.remove('far');
            icon.classList.add('fas');
            this.style.color = 'var(--accent)'; // Apply accent color when liked
        } else {
            icon.classList.remove('fas');
            icon.classList.add('far');
            this.style.color = 'var(--gray)'; // Revert to default color
        }
    });
});



// Profile dropdown toggle for desktop
const profileButton = document.getElementById('profileButton');
const profileDropdown = document.getElementById('profileDropdown');

if (profileButton && profileDropdown) {
    profileButton.addEventListener('click', function(e) {
        e.stopPropagation(); // Prevent click from bubbling up and closing immediately
        profileDropdown.classList.toggle('show');
    });
}

// Mobile profile button (currently just an alert)
const mobileProfileButton = document.getElementById('mobileProfileButton');
if (mobileProfileButton) {
    mobileProfileButton.addEventListener('click', function(e) {
        e.stopPropagation();
        alert("This button would open a mobile-friendly profile menu!");
        // You would typically open a modal or navigate to a profile page here.
    });
}

// Close profile dropdown when clicking anywhere outside it
document.addEventListener('click', function(e) {
    if (profileDropdown && profileDropdown.classList.contains('show') && !profileDropdown.contains(e.target) && e.target !== profileButton) {
        profileDropdown.classList.remove('show');
    }
});

// Prevent dropdown from closing when clicking inside it
if (profileDropdown) {
    profileDropdown.addEventListener('click', function(e) {
        e.stopPropagation(); // Keep dropdown open when clicking within it
    });
}</script>
</body>
</html>